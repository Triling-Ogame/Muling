// Manual saving only. No request to OGame and no automatic espionage action.
(()=>{
 const observer=document.querySelector('meta[name="ogame-player-id"]')?.content;if(!observer)return;
 const scopeKey=`${location.host}:${observer}`,label=document.querySelector('meta[name="ogame-universe-name"]')?.content||location.host;
 let saved=new Set(),timer;
 function parse(message){const raw=message.querySelector('.rawMessageData'),attrs=Object.fromEntries([...raw.attributes].map(a=>[a.name,a.value]));return MulingSpyCore.fromAttributes(attrs,message.getAttribute('data-msg-id'),message.getAttribute('data-messages-filters-timestamp'),message.querySelector('.msgTitle')?.textContent?.trim()||'')}
 function refreshSaved(scope){saved=new Set((scope?.spyReports||[]).map(r=>r.messageId));scan()}
 chrome.storage.local.get('mulingSurveillance',value=>refreshSaved(value.mulingSurveillance?.scopes?.[scopeKey]));
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.mulingSurveillance)refreshSaved(changes.mulingSurveillance.newValue?.scopes?.[scopeKey])});
 function scan(){
  const reports=new Map([...document.querySelectorAll('.msg[data-msg-id]')].filter(m=>m.querySelector('.rawMessageData')).map(m=>[m.getAttribute('data-msg-id'),m]));
  for(const [id,message] of reports){
   const locations=[message.querySelector('message-footer-actions')||message.querySelector('.msgHead')];
   const row=document.querySelector(`tr[data-report-id="${id}"]`);if(row?.querySelector('.ogl-spyOptions'))locations.unshift(row.querySelector('.ogl-spyOptions'));
   // rawMessageData also exists on expedition and fleet messages.
   // Only a complete, valid espionage payload may receive a save button.
   let validReport=false;try{parse(message);validReport=true}catch{}
   for(const container of locations.filter(Boolean)){
    if(!validReport){container.querySelector('.muling-spy-save')?.remove();continue}

    let button=container.querySelector('.muling-spy-save');if(!button){button=document.createElement('button');button.type='button';button.className='muling-spy-save';button.dataset.reportId=id;container.append(button);
     button.addEventListener('click',async event=>{event.preventDefault();event.stopPropagation();button.disabled=true;try{const current=document.querySelector(`.msg[data-msg-id="${id}"]`);if(!current?.querySelector('.rawMessageData'))throw Error('Le RE n’est plus présent sur cette page');const report=parse(current),response=await chrome.runtime.sendMessage({type:'mulingSurveillance:spySave',observer,label,report});if(!response?.ok)throw Error(response?.error||'Sauvegarde impossible');saved.add(id);button.title='RE sauvegardé dans Muling';button.textContent='✓';button.setAttribute('aria-label',button.title)}catch(error){button.textContent='!';button.title=error.message;button.setAttribute('aria-label',error.message)}finally{button.disabled=false}});
    }
    const title=saved.has(id)?'RE sauvegardé dans Muling':'Sauvegarder le RE dans Muling et suivre ce joueur';
    if(button.title!==title){button.title=title;button.setAttribute('aria-label',title)}const text=saved.has(id)?'✓':'M';if(button.textContent!==text)button.textContent=text;
   }
  }
 }
 function schedule(){if(timer)return;timer=setTimeout(()=>{timer=null;scan()},150)}
 new MutationObserver(schedule).observe(document.documentElement,{subtree:true,childList:true});scan();
})();
