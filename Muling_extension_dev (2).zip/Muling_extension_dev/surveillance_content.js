// Reads rendered galaxy rows only. No galaxy request, navigation, or game action.
// Row/name/debris classes are also used by OGLight's published Galaxy manager:
// https://greasyfork.org/en/scripts/514909-oglight/code
(()=>{
 const core=MulingSurveillanceCore;
 const observer=document.querySelector('meta[name="ogame-player-id"]')?.content;
 if(!observer)return;
 const universe=location.host,scopeKey=`${universe}:${observer}`,label=document.querySelector('meta[name="ogame-universe-name"]')?.content||universe;
 let targets=[],timer,galaxyNode,lastSignature='',lastRows=[],lastDiagnostic='';
 chrome.runtime.sendMessage({type:'mulingSurveillance:identify',observer,label}).catch(()=>{});
 chrome.storage.local.get('mulingSurveillance',data=>{targets=data.mulingSurveillance?.scopes?.[scopeKey]?.targets||[];observeGalaxy();schedule()});
 chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local'||!changes.mulingSurveillance)return;const next=changes.mulingSurveillance.newValue?.scopes?.[scopeKey]?.targets||[];if(JSON.stringify(next)!==JSON.stringify(targets)){targets=next;lastSignature='';schedule()}});
 function readActivity(cell){
  if(!cell)return null;
  // Read activity metadata on the visible galaxy row. Its icon may have no
  // layout rectangle when another addon restyles the warning graphic.
  const icon=cell.querySelector('.activity');if(!icon)return 'inactive';
  const text=icon.textContent.trim();
  if(text===''||text==='*'||icon.classList.contains('minute15')||icon.classList.contains('active'))return '*';
  const minutes=Number(text);if(Number.isInteger(minutes)&&minutes>=15&&minutes<=60)return minutes;
  const hint=[icon.getAttribute('title'),icon.getAttribute('data-tooltip-content'),icon.getAttribute('data-tooltip-title')].filter(Boolean).join(' ');
  if(/(?:<|less|moins|inf[eé]rieur).*15|last 15|derni[eè]res? 15/i.test(hint))return '*';
  const match=hint.match(/(?:^|\D)([1-5]\d|60)\s*(?:min|minutes)/i);return match?Number(match[1]):null;
 }
 function readDebris(cell){
  if(!cell)return {present:null,metal:null,crystal:null,deut:null};
  const icon=cell.querySelector('.microdebris');if(!icon)return {present:false,metal:0,crystal:0,deut:0};
  const raw=[cell.textContent,...[cell,...cell.querySelectorAll('[title], [data-tooltip-content], [data-tooltip-title]')].flatMap(el=>['title','data-tooltip-content','data-tooltip-title'].map(attr=>el.getAttribute(attr)||''))].join(' ');
  // Strip tags without inserting tooltip HTML into the live page.
  const plain=raw.replace(/<[^>]*>/g,' ').replace(/&(?:nbsp|#160);/g,' ').replace(/\s+/g,' ');
  const amount=words=>{const match=plain.match(new RegExp(`(?:${words})\\s*:?\\s*([\\d][\\d\\s.,]*)`,'i'));if(!match)return null;const n=Number(match[1].replace(/\s|\./g,'').replace(',','.'));return Number.isSafeInteger(n)&&n>=0?n:null};
  return {present:true,metal:amount('métal|metal'),crystal:amount('cristal|crystal'),deut:amount('deutérium|deuterium|deut')};
 }
 function playerName(row){
  const cell=row.querySelector('.cellPlayerName');if(!cell)return null;
  const elements=[...cell.querySelectorAll('[class*="status_abbr"], .playername, [data-player-name], a, span')];
  const names=elements.map(el=>el.getAttribute('data-player-name')||el.textContent).concat(cell.textContent).map(x=>String(x||'').trim());
  return targets.find(t=>names.some(name=>core.nameKey(name)===t.key))?.name||null;
 }
 function visibleRow(row){const rect=row.getBoundingClientRect();return row.getClientRects().length>0&&rect.bottom>0&&rect.top<innerHeight&&rect.right>0&&rect.left<innerWidth}
 function diagnostic(message){if(message===lastDiagnostic)return;lastDiagnostic=message;chrome.storage.local.set({[`mulingSurveillanceDiagnostic:${scopeKey}`]:{message,at:Date.now()}}).catch(()=>{})}
 function collect(){
  if(document.visibilityState!=='visible'||!targets.length||!galaxyNode)return;
  const params=new URLSearchParams(location.search);if(params.get('component')!=='galaxy'&&params.get('page')!=='galaxy')return;
  const clockText=document.querySelector('.OGameClock')?.textContent?.replace(/\s+/g,' ').trim(),clock=core.clock(clockText);if(!clock){diagnostic('Horloge serveur non reconnue : relevé bloqué');return}
  const galaxy=Number(document.querySelector('#galaxy_input')?.value),system=Number(document.querySelector('#system_input')?.value);
  if(!Number.isInteger(galaxy)||galaxy<1||!Number.isInteger(system)||system<1){diagnostic('Coordonnées du système non reconnues : relevé bloqué');return}
  const rows=[...galaxyNode.querySelectorAll('[id^="galaxyRow"]')].filter(visibleRow),observations=[];
  for(const row of rows){const position=Number(row.id.replace('galaxyRow',''));if(position<1||position>15)continue;const player=playerName(row);if(!player)continue;
   const planet=row.querySelector('.cellPlanet'),moon=row.querySelector('.cellMoon'),moonPresent=!!moon?.querySelector('.micromoon, .microplanet, img');
   observations.push({player,coords:`${galaxy}:${system}:${position}`,planet:readActivity(planet),moon:moonPresent?readActivity(moon):null,moonPresent,debris:readDebris(row.querySelector('.cellDebris')),clock:clockText});
  }
  // DOM mutations can fire repeatedly for one rendering. Never manufacture a
  // new observation for every ticking clock or for a stationary table.
  diagnostic(`Lecteur 0.0.49 · ${rows.length} positions visibles · ${observations.length} position(s) suivie(s)${observations.map(o=>` · [${o.coords}] planète ${o.planet??'?'} / lune ${o.moon??'?'}`).join('')}`);
  const signature=JSON.stringify(observations.map(({clock,...rest})=>rest)),replaced=rows.length!==lastRows.length||rows.some((row,i)=>row!==lastRows[i]);
  if(signature===lastSignature&&!replaced)return;lastSignature=signature;lastRows=rows;
  if(observations.length)chrome.runtime.sendMessage({type:'mulingSurveillance:record',observer,label,observations}).then(result=>{if(!result?.ok)diagnostic(`Enregistrement refusé : ${result?.error||'réponse absente'}`)}).catch(error=>diagnostic(`Enregistrement impossible : ${error.message}`));
 }
 function schedule(){if(timer)return;timer=setTimeout(()=>{timer=null;collect()},450)}
 function observeGalaxy(){const node=document.querySelector('#galaxyContent');if(!node){if(new URLSearchParams(location.search).get('component')==='galaxy')diagnostic('Tableau galaxie non reconnu : relevé bloqué');return}if(node===galaxyNode)return;galaxyNode=node;lastSignature='';lastRows=[];new MutationObserver(schedule).observe(node,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','title','data-tooltip-content','data-tooltip-title']});schedule()}
 new MutationObserver(observeGalaxy).observe(document.documentElement,{subtree:true,childList:true});
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){observeGalaxy();schedule()}});
 addEventListener('scroll',schedule,{passive:true});
 observeGalaxy();
})();
