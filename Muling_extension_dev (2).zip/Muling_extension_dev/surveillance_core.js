/* Observations only: an empty bucket means not observed, never inactivity. */
const MulingSurveillanceCore=Object.freeze({
 nameKey(name){return String(name||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase('fr-FR')},
 slotLabel(index){const m=((index+1)*15)%1440;return `${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`},
 clock(text){
  const m=String(text||'').match(/(\d{2})[./](\d{2})[./](\d{4})\s+(\d{2}):(\d{2}):(\d{2})/);
  if(!m)return null;
  const [,d,mo,y,h,mi,se]=m.map((v,i)=>i?Number(v):v),stamp=Date.UTC(y,mo-1,d,h,mi,se),date=new Date(stamp);
  if(date.getUTCFullYear()!==y||date.getUTCMonth()!==mo-1||date.getUTCDate()!==d||h>23||mi>59||se>59)return null;
  return {day:`${y}-${String(mo).padStart(2,'0')}-${String(d).padStart(2,'0')}`,time:`${String(h).padStart(2,'0')}:${String(mi).padStart(2,'0')}:${String(se).padStart(2,'0')}`,stamp,slot:Math.floor((h*60+mi)/15)};
 },
 add(scope,observation){
  const key=this.nameKey(observation.player),target=scope.targets?.find(t=>t.key===key);
  if(!target||!/^\d+:\d+:\d+$/.test(observation.coords))return false;
  const clock=this.clock(observation.clock);if(!clock)return false;
  const activity=x=>x==='*'||x==='inactive'||x===null||Number.isInteger(x)&&x>=15&&x<=60?x:null;
  const debris=observation.debris||{},number=x=>Number.isSafeInteger(x)&&x>=0?x:null;
  const record={time:clock.time,stamp:clock.stamp,planet:activity(observation.planet),moon:activity(observation.moon),moonPresent:!!observation.moonPresent,debris:{present:debris.present===true?true:debris.present===false?false:null,metal:number(debris.metal),crystal:number(debris.crystal),deut:number(debris.deut)}};
  const ensure=(map,key,value)=>{if(!Object.hasOwn(map,key))Object.defineProperty(map,key,{value,writable:true,enumerable:true,configurable:true});return map[key]};
  scope.days=scope.days||{};const day=ensure(scope.days,clock.day,{});const player=ensure(day,key,{name:target.name,positions:{}});const bins=ensure(player.positions,observation.coords,{});const bucket=ensure(bins,clock.slot,[]);
  const sources=Array.isArray(observation.sources)?observation.sources:[];record.sources=[...new Map(sources.filter(v=>v&&typeof v.id==='string'&&typeof v.label==='string').slice(0,20).map(v=>[v.id.slice(0,160),{id:v.id.slice(0,160),label:v.label.slice(0,80)}])).values()];
  const same=(a,b)=>JSON.stringify({...a,time:undefined,stamp:undefined,sources:undefined})===JSON.stringify({...b,time:undefined,stamp:undefined,sources:undefined});
  const duplicate=bucket.find(v=>v.time===record.time&&same(v,record));
  if(duplicate){duplicate.sources=[...new Map([...(duplicate.sources||[]),...record.sources].map(v=>[v.id,v])).values()].slice(0,20);return false;}
  bucket.push(record);bucket.sort((a,b)=>a.stamp-b.stamp);if(bucket.length>24)bucket.splice(0,bucket.length-24);
  scope.lastDay=Object.keys(scope.days).sort().at(-1);if(clock.stamp>=Number(scope.lastStamp||0)){scope.lastStamp=clock.stamp;scope.lastObservation=`${clock.day} ${clock.time}`}
  const cutoff=new Date(Date.parse(`${scope.lastDay}T00:00:00Z`)-29*86400000).toISOString().slice(0,10);
  for(const day of Object.keys(scope.days))if(day<cutoff)delete scope.days[day];
  return true;
 }
});

/* Portable surveillance files. Imports merge into the selected universe only. */
const MulingSurveillanceTransfer=Object.freeze({
 exportScope(scope,playerKey,label){
  if(!scope?.universe)throw Error('Ouvre OGame pour identifier ton univers');
  const copy=JSON.parse(JSON.stringify(scope));
  if(playerKey){copy.targets=copy.targets.filter(t=>t.key===playerKey);for(const day of Object.values(copy.days||{}))for(const key of Object.keys(day))if(key!==playerKey)delete day[key];copy.hiddenPositions={};copy.spyReports=(copy.spyReports||[]).filter(r=>r.playerKey===playerKey);}
  const source={id:`${scope.universe}:${scope.observer}`,label:String(label||scope.contributorName||`Compte ${scope.observer}`).trim().slice(0,80)};
  for(const day of Object.values(copy.days||{}))for(const player of Object.values(day))for(const bins of Object.values(player.positions||{}))for(const records of Object.values(bins))for(const record of records)if(!record.sources?.length)record.sources=[source];else record.sources=record.sources.map(s=>s.id===source.id?source:s);
  for(const report of copy.spyReports||[])report.sources=report.sources?.length?report.sources.map(s=>s.id===source.id?source:s):[source];
  return {format:'muling-surveillance',version:1,exportedAt:new Date().toISOString(),scope:copy};
 },
 merge(scope,file,restoreHidden=false){
  if(file?.format!=='muling-surveillance'||file.version!==1||!file.scope||typeof file.scope!=='object')throw Error('Fichier de surveillance Muling non reconnu');
  const input=file.scope;
  if(input.universe!==scope.universe)throw Error('Ce fichier provient d’un autre univers. Sélectionne le bon univers avant l’import.');
  if(!Array.isArray(input.targets)||input.targets.length>500||!input.days||typeof input.days!=='object'||Array.isArray(input.days))throw Error('Données de surveillance invalides');
  const names=new Map((scope.targets||[]).map(t=>[t.key,t]));
  for(const target of input.targets){const name=String(target?.name||'').trim().replace(/\s+/g,' ');if(!name||name.length>80||MulingSurveillanceCore.nameKey(name)!==target.key)throw Error('Pseudo invalide dans le fichier');if(!names.has(target.key))names.set(target.key,{name,key:target.key,...(/^\d+$/.test(target.playerId||'')?{playerId:target.playerId}:{})});else if(target.playerId){const current=names.get(target.key);if(current.playerId&&current.playerId!==target.playerId)throw Error('Ce pseudo appartient à un autre joueur');if(/^\d+$/.test(target.playerId))names.set(target.key,{...current,playerId:target.playerId});}}
  if(names.size>500)throw Error('500 cibles maximum après fusion');
  const targets=[...names.values()],work=JSON.parse(JSON.stringify(scope));work.targets=targets;
  for(const day of Object.values(work.days||{}))for(const player of Object.values(day))for(const bins of Object.values(player.positions||{}))for(const records of Object.values(bins))for(const record of records)if(!record.sources?.length)record.sources=[{id:`${scope.universe}:${scope.observer}`,label:scope.contributorName||`Compte ${scope.observer}`}];
  const report={added:0,duplicates:0,ignored:0,targetsAdded:targets.length-(scope.targets||[]).length,reportsAdded:0,reportsDuplicates:0};let count=0;
  const observations=[];
  for(const [day,players] of Object.entries(input.days)){
   if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||!players||typeof players!=='object'||Array.isArray(players))throw Error('Date invalide dans le fichier');
   const [year,month,date]=day.split('-');
   for(const [key,player] of Object.entries(players)){
    if(!player||typeof player!=='object'||MulingSurveillanceCore.nameKey(player.name)!==key||!player.positions||typeof player.positions!=='object')throw Error('Historique joueur invalide');
    const name=String(player.name);if(name.length>80)throw Error('Pseudo trop long');
    for(const [coords,bins] of Object.entries(player.positions)){
     if(!/^([1-9]\d*):([1-9]\d*):([1-9]|1[0-5])$/.test(coords)||!bins||typeof bins!=='object'||Array.isArray(bins))throw Error('Coordonnées invalides');
     for(const [slot,records] of Object.entries(bins)){
      if(!/^\d+$/.test(slot)||Number(slot)>95||!Array.isArray(records)||records.length>24)throw Error('Créneau invalide');
      for(const record of records){
       if(++count>100000)throw Error('Fichier trop volumineux : 100 000 relevés maximum');
       const clock=`${date}.${month}.${year} ${record?.time}`,parsed=MulingSurveillanceCore.clock(clock);
       const validActivity=v=>v===null||v==='*'||v==='inactive'||Number.isInteger(v)&&v>=15&&v<=60;
       const d=record?.debris,validNumber=v=>v===null||Number.isSafeInteger(v)&&v>=0;
       if(!parsed||parsed.slot!==Number(slot)||!validActivity(record.planet)||!validActivity(record.moon)||typeof record.moonPresent!=='boolean'||!d||![true,false,null].includes(d.present)||![d.metal,d.crystal,d.deut].every(validNumber))throw Error('Relevé invalide dans le fichier');
       const sources=record.sources?.length?record.sources:[{id:`${input.universe}:${String(input.observer||'import')}`,label:`Compte ${String(input.observer||'import')}`}];
       observations.push({player:name,coords,clock,planet:record.planet,moon:record.moon,moonPresent:record.moonPresent,debris:d,sources,stamp:parsed.stamp,key});
      }
     }
    }
   }
  }
  const newest=observations.reduce((n,o)=>Math.max(n,o.stamp),Number(work.lastStamp||0)),cutoff=newest-30*86400000;
  observations.sort((a,b)=>a.stamp-b.stamp);
  for(const observation of observations){if(observation.stamp<=cutoff){report.ignored++;continue}const archived=!work.targets.some(t=>t.key===observation.key);if(archived)work.targets.push({name:observation.player,key:observation.key});if(MulingSurveillanceCore.add(work,observation))report.added++;else report.duplicates++;if(archived)work.targets.pop();}
  if(restoreHidden&&input.observer===scope.observer&&input.hiddenPositions&&typeof input.hiddenPositions==='object'){
   work.hiddenPositions=work.hiddenPositions||{};
   for(const [key,coords] of Object.entries(input.hiddenPositions))if(names.has(key)&&Array.isArray(coords)){const old=Object.hasOwn(work.hiddenPositions,key)?work.hiddenPositions[key]:[];Object.defineProperty(work.hiddenPositions,key,{value:[...new Set([...old,...coords.filter(c=>typeof c==='string'&&/^\d+:\d+:\d+$/.test(c))])],writable:true,enumerable:true,configurable:true});}
  }
  if(input.spyReports!==undefined){if(!Array.isArray(input.spyReports)||input.spyReports.length>1000)throw Error('Liste de RE invalide');for(const item of input.spyReports){const result=MulingSpyCore.save(work,item);if(result.added)report.reportsAdded++;else report.reportsDuplicates++;}}
  Object.assign(scope,work);return report;
 }
});
