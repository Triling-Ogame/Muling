// Serialize writes from all game tabs to keep simultaneous observations.
let surveillanceWriteQueue=Promise.resolve();
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(!String(message?.type||'').startsWith('mulingSurveillance:'))return;
 surveillanceWriteQueue=surveillanceWriteQueue.catch(()=>{}).then(async()=>{
  const result=await chrome.storage.local.get('mulingSurveillance'),state=result.mulingSurveillance||{scopes:{}};state.scopes=state.scopes||{};
  const isGame=!!sender.tab&&/^https:\/\/[^/]+\.ogame\.gameforge\.com\//.test(sender.url||sender.tab.url||'');
  let key=message.scope;
  if(isGame){const universe=new URL(sender.url||sender.tab.url).host,observer=String(message.observer||'');if(!/^\d+$/.test(observer))throw Error('Compte OGame absent');key=`${universe}:${observer}`;state.scopes[key]=state.scopes[key]||{universe,observer,targets:[],days:{}};state.scopes[key].label=String(message.label||universe).slice(0,80);state.lastScope=key}
  const scope=state.scopes[key];if(!scope)throw Error('Ouvre une page OGame pour identifier l’univers');
  if(message.type==='mulingSurveillance:targets'){
   if(isGame)throw Error('Réglage depuis Muling uniquement');
   if(!Array.isArray(message.targets)||message.targets.length>500)throw Error('500 joueurs maximum');
   const targets=new Map();for(const value of message.targets){const name=String(value||'').trim().replace(/\s+/g,' ');if(!name||name.length>80)continue;const normalized=MulingSurveillanceCore.nameKey(name);targets.set(normalized,{...scope.targets.find(t=>t.key===normalized),name,key:normalized})}scope.targets=[...targets.values()];
  }else if(message.type==='mulingSurveillance:rename'){
   if(isGame)throw Error('Réglage depuis Muling uniquement');
   const target=scope.targets.find(t=>t.key===message.player),name=String(message.name||'').trim().replace(/\s+/g,' '),next=MulingSurveillanceCore.nameKey(name);
   if(!target||!name||name.length>80)throw Error('Pseudo invalide');
   if(next!==target.key&&(scope.targets.some(t=>t.key===next)||Object.values(scope.days||{}).some(day=>Object.hasOwn(day,next))))throw Error('Ce pseudo possède déjà un suivi ou un historique');
   const previous=target.key;
   for(const day of Object.values(scope.days||{}))if(Object.hasOwn(day,previous)){const player=day[previous];player.name=name;if(previous!==next){Object.defineProperty(day,next,{value:player,writable:true,enumerable:true,configurable:true});delete day[previous]}}
   scope.hiddenPositions=scope.hiddenPositions||{};
   if(previous!==next&&Object.hasOwn(scope.hiddenPositions,previous)){Object.defineProperty(scope.hiddenPositions,next,{value:scope.hiddenPositions[previous],writable:true,enumerable:true,configurable:true});delete scope.hiddenPositions[previous]}
   for(const report of scope.spyReports||[])if(report.playerKey===previous)report.playerKey=next;
   target.name=name;target.key=next;
  }else if(message.type==='mulingSurveillance:position'){
   if(isGame)throw Error('Réglage depuis Muling uniquement');
   if(!scope.targets.some(t=>t.key===message.player)||!/^\d+:\d+:\d+$/.test(message.coords))throw Error('Position invalide');
   scope.hiddenPositions=scope.hiddenPositions||{};
   const hidden=Object.hasOwn(scope.hiddenPositions,message.player)?scope.hiddenPositions[message.player]:[];
   Object.defineProperty(scope.hiddenPositions,message.player,{value:message.hidden?[...new Set([...hidden,message.coords])]:hidden.filter(c=>c!==message.coords),writable:true,enumerable:true,configurable:true});
  }else if(message.type==='mulingSurveillance:profile'){
   if(isGame)throw Error('Réglage depuis Muling uniquement');
   const name=String(message.name||'').trim().slice(0,80);scope.contributorName=name;
   const ownId=`${scope.universe}:${scope.observer}`,label=name||`Compte ${scope.observer}`,update=record=>{record.sources=record.sources?.length?record.sources.map(source=>source.id===ownId?{...source,label}:source):[{id:ownId,label}]};
   for(const day of Object.values(scope.days||{}))for(const player of Object.values(day))for(const bins of Object.values(player.positions||{}))for(const records of Object.values(bins))for(const record of records)update(record);
   for(const report of scope.spyReports||[])update(report);
  }else if(message.type==='mulingSurveillance:spySave'){
   if(!isGame)throw Error('Sauvegarde depuis OGame uniquement');
   MulingSpyCore.save(scope,{...message.report,sources:[{id:`${scope.universe}:${scope.observer}`,label:scope.contributorName||`Compte ${scope.observer}`} ]});
  }else if(message.type==='mulingSurveillance:spyDelete'){
   if(isGame)throw Error('Suppression depuis Muling uniquement');
   scope.spyReports=(scope.spyReports||[]).filter(r=>r.id!==message.id);
  }else if(message.type==='mulingSurveillance:import'){
   if(isGame)throw Error('Import depuis Muling uniquement');
   scope.importReport=MulingSurveillanceTransfer.merge(scope,message.file,!!message.restoreHidden);
  }else if(message.type==='mulingSurveillance:record'){
   if(!isGame)throw Error('Relevé depuis la galaxie uniquement');
   for(const item of Array.isArray(message.observations)?message.observations.slice(0,15):[])MulingSurveillanceCore.add(scope,{...item,sources:[{id:`${scope.universe}:${scope.observer}`,label:scope.contributorName||`Compte ${scope.observer}`} ]});
  }else if(message.type!=='mulingSurveillance:identify')return;
  await chrome.storage.local.set({mulingSurveillance:state});reply({ok:true,scope:key,scopeData:scope});
 }).catch(error=>reply({ok:false,error:error.message}));
 return true;
});
