
const $=id=>document.getElementById(id), names={1:'Métal',2:'Cristal',3:'Deutérium'};
let account=null, planets=[], expeditionMonth=null, oglightMonths=[], lfCatalog=null, workbookReference=null, unlockReference=null, buildingNames=null;
const markerDefaults={mine:true,lf:true,building:true,freight:true};
let dailyExpeditionSettings=null;
try{dailyExpeditionSettings=JSON.parse(localStorage.getItem('muling:expeditions:daily'))||null}catch{}
let markerOptions={...markerDefaults,...JSON.parse(localStorage.getItem('muling:markers')||'{}')};
for(const [name,id] of [['mine','marker-mine'],['lf','marker-lf'],['building','marker-building'],['freight','marker-freight']]){const input=$(id);input.checked=markerOptions[name];input.addEventListener('change',()=>{markerOptions[name]=input.checked;localStorage.setItem('muling:markers',JSON.stringify(markerOptions));publishMarkers();renderRaider();renderRecycler();if(!combatCount.value)combatCount.value=combatShip.value==='all'?'':storedShipCount(combatShip.value);renderCombat()})}
const resource=(n,type)=>`<span class="resource ${type}">${fmtCost(n)}</span>`;
fetch('lf_catalog.json').then(r=>r.json()).then(data=>{lfCatalog=data;render()}).catch(()=>{$('status').textContent='Catalogue FDV indisponible'});
fetch('workbook_reference.json').then(r=>r.json()).then(data=>{workbookReference=data;render()}).catch(()=>{});
fetch('unlock_reference.json').then(r=>r.json()).then(data=>{unlockReference=data;render()}).catch(()=>{});
fetch('building_names.json').then(r=>r.json()).then(data=>{buildingNames=data;render()}).catch(()=>{});
const speciesNames={701:'Human',702:'Rocktal',703:'Mecha',704:'Kaelesh'};
function goalKey(p){return `muling:unlock:${account.playerId}:${p.id}`}
function unlockGoal(p){const slot=Number(localStorage.getItem(goalKey(p))||0);return slot>=1&&slot<=18?slot:0}
function unlockNext(p){const slot=unlockGoal(p),row=unlockReference?.[p.selectedSpeciesId]?.[slot];if(!row)return null;let planned=false;const missing=row.levels.flatMap((required,i)=>{const id=String(11101+(Number(p.selectedSpeciesId)-701)*1000+i),level=Number(p.speciesBuildings?.[id]||0),queued=Number(p.pendingBuildings?.[id]||0);if(level<required&&queued>=required)planned=true;return Math.max(level,queued)<required?[{id,level,queued,required}]:[]});return {slot,missing,done:missing.length===0,planned}}
function unlockChoices(p){const selected=unlockGoal(p);return `<label class="goal-label">Objectif FDV <select data-goal="${p.id}"><option value="0">Aucun</option>${Array.from({length:18},(_,i)=>{const slot=i+1,tier=Math.ceil(slot/6),place=(slot-1)%6+1;return `<option value="${slot}" ${slot===selected?'selected':''}>T${tier}-${place}</option>`}).join('')}</select></label>`}
function activeLf(p,includeZero=false){const selected=new Set((p.selectedSpeciesTechnologyIds||[]).map(String));return Object.entries(p.speciesResearches||{}).filter(([id,level])=>(includeZero?Number(level)>=0:Number(level)>0)&&selected.has(id)&&lfCatalog?.[id]).map(([id,level])=>{const tech=lfCatalog[id],effective=p.pendingResearch?.id===id?Math.max(Number(level),Number(p.pendingResearch.nextLevel||0)):Number(level),next=effective+1;return {id,level:effective,tech,cost:tech.base.map((base,i)=>Math.trunc(base*Math.pow(tech.factor[i],next-1)*next))}}).sort((a,b)=>a.tech.slot-b.tech.slot)}
function expeditionLfCandidates(p){
 if(!expeditionMonth||!lfCatalog)return [];
 const all=planets.filter(v=>v.included).flatMap(v=>activeLf(v));
 const bonusFor=effect=>all.filter(x=>x.tech.effect===effect).reduce((sum,x)=>sum+x.level*Number(x.tech.bonusPerLevel||0),0);
 const resourceBonus=bonusFor('Expo Res Boost'),shipBonus=bonusFor('Expo Find more Ships'),classBonus=bonusFor('Discoverer Class Boost');
 return activeLf(p,true).flatMap(x=>{
  const bonus=Number(x.tech.bonusPerLevel||0);let gainPerDay=0;
  if(x.tech.effect==='Expo Res Boost')gainPerDay=expeditionMonth.msuPerDay*bonus/(100+resourceBonus);
  if(Number.isFinite(expeditionMonth.shipsMsuPerDay)&&x.tech.effect==='Expo Find more Ships')gainPerDay=expeditionMonth.shipsMsuPerDay*bonus/(100+shipBonus);
  if(Number.isFinite(expeditionMonth.shipsMsuPerDay)&&Number(account?.characterClassId)===3&&x.tech.effect==='Discoverer Class Boost')gainPerDay=(expeditionMonth.msuPerDay+expeditionMonth.shipsMsuPerDay)*bonus/(100+classBonus);
  return gainPerDay>0?[{...x,days:(x.cost[0]+1.5*x.cost[1]+3*x.cost[2])/gainPerDay,source:expeditionMonth.source==='theory'?'expedition-theory':'expedition-estimate'}]:[];
 }).filter(x=>Number.isFinite(x.days)).sort((a,b)=>a.days-b.days);
}
function expeditionLfCandidate(p){return expeditionLfCandidates(p)[0]||null}
function refreshDailyExpeditions(){
 updateExpeditionSourceControls();
 const box=$('exp-daily-result');
 if(expeditionMonth?.source!=='theory'){box.textContent=expeditionMonth?'Historique utilisé pour le calcul. Clique sur « Utiliser cette estimation » pour passer au mode quotidien.':'Renseigne ta moyenne quotidienne. Buzz : économie ×5.';return}
 if(!account||!lfCatalog){box.textContent='Estimation enregistrée : importe ton compte pour appliquer sa classe et ses FDV.';return}
 const all=planets.filter(p=>p.included).flatMap(p=>activeLf(p));
 const bonus=effect=>all.filter(x=>x.tech.effect===effect).reduce((sum,x)=>sum+x.level*Number(x.tech.bonusPerLevel||0),0);
 const estimate=MulingExpeditionModel.estimate({...dailyExpeditionSettings,commander:!!account.officers?.commander,discoverer:Number(account.characterClassId)===3,resourceBonus:bonus('Expo Res Boost'),shipBonus:bonus('Expo Find more Ships'),classBonus:bonus('Discoverer Class Boost')});
 if(!estimate){box.textContent='Vérifie le nombre quotidien et l’économie de l’univers.';return}
 expeditionMonth=estimate;
 localStorage.setItem('muling:expeditions:last',JSON.stringify(estimate));
 box.innerHTML=`<b>${fmt(estimate.perDay)} expéditions/jour · économie ×${estimate.economy}</b><br>Ressources estimées/jour : ${resource(estimate.metalPerExpedition*estimate.perDay,'metal')} · ${resource(estimate.crystalPerExpedition*estimate.perDay,'crystal')} · ${resource(estimate.deutPerExpedition*estimate.perDay,'deuterium')}<br>${fmtCost(estimate.msuPerDay)} USM/jour en ressources · ${fmtCost(estimate.shipsMsuPerDay)} USM/jour en vaisseaux trouvés.<br><small>Classe ${Number(account.characterClassId)===3?'explorateur':'non explorateur'} · bonus FDV ressources ${fmt(estimate.resourceBonus)} % · estimation théorique selon les réglages ci-dessus.</small>`;
 const history=normalizeExpeditionHistory(expeditionHistories[lastExpeditionHistorySource]);
 if(history&&Number.isFinite(history.msuPerDay))box.innerHTML+=`<br><small>Historique sauvegardé : ${fmt(history.perDay)} expéditions/jour · ${fmtCost(history.msuPerDay)} USM/jour en ressources. Estimation actuelle : ${fmtCost(estimate.msuPerDay)} USM/jour.</small>`;
}

function nextLf(p){if(expeditionMonth?.source==='theory'||Number.isFinite(expeditionMonth?.msuPerDay))return expeditionLfCandidate(p);const snapshot=workbookReference?.planets?.[p.id];if(!snapshot||String(workbookReference.playerId)!==String(account?.playerId))return expeditionLfCandidate(p);const levels=p.speciesResearches||{},stale=!!p.pendingResearch||workbookReference.exportedAt!==account?.exportedAt||Object.entries(snapshot.levels).some(([id,level])=>Number(levels[id]||0)!==Number(level));const choices=activeLf(p,true),reference=(snapshot.priorities||[]).filter(x=>x.kind==='lf'&&Number.isFinite(x.days));const msu=c=>c[0]+1.5*c[1]+3*c[2];const oldCost=r=>{const tech=lfCatalog[r.id];return tech?msu(tech.base.map((v,i)=>Math.trunc(v*tech.factor[i]**r.level*(r.level+1)))):0};const scored=choices.flatMap(choice=>{const direct=reference.find(r=>r.id===choice.id);const proxy=reference.find(r=>lfCatalog[r.id]?.effect===choice.tech.effect&&Number(lfCatalog[r.id]?.bonusPerLevel)>0)||direct;if(!proxy)return [];const baseline=oldCost(proxy),bonusRatio=Number(lfCatalog[proxy.id].bonusPerLevel)/Number(choice.tech.bonusPerLevel);return baseline>0&&Number.isFinite(bonusRatio)?[{choice,days:proxy.days*msu(choice.cost)/baseline*bonusRatio}]:[]}).sort((a,b)=>a.days-b.days);const chosen=scored[0]?.choice||choices.find(x=>x.id===snapshot.techId);return chosen?{...chosen,days:stale?null:(scored[0]?.days??snapshot.nextLevelDays),lastDays:scored[0]?.days??snapshot.nextLevelDays,stale}:null}
function nextBuilding(p){const snapshot=workbookReference?.planets?.[p.id]?.building;if(!snapshot||String(workbookReference.playerId)!==String(account?.playerId)||Number(p.selectedSpeciesId)!==Number(snapshot.speciesId))return null;const levels=p.speciesBuildings||{},stale=workbookReference.exportedAt!==account?.exportedAt||Object.entries(snapshot.levels).some(([id,level])=>Number(levels[id]||0)!==Number(level));const ranked=(workbookReference.planets[p.id].priorities||[]).filter(x=>x.kind==='building');const chosen=ranked.find(x=>Number(levels[x.id]||0)===Number(x.level))||ranked[0]||snapshot;const level=Number(levels[chosen.id]||0);return {...snapshot,id:chosen.id,name:chosen.name||snapshot.name,level,days:stale?null:chosen.days,lastDays:chosen.days,stale,cost:stale?null:snapshot.cost}}
function astroCapacity(){const level=Number(account?.researches?.[124]);return Number.isInteger(level)&&level>=0?{level,colonies:Math.floor((level+1)/2),planets:Math.floor((level+1)/2)+1}:null}
let expeditionHistories={},lastExpeditionHistorySource='';
try{expeditionHistories=JSON.parse(localStorage.getItem('muling:expeditions:histories'))||{};if(Array.isArray(expeditionHistories)||typeof expeditionHistories!=='object')expeditionHistories={}}catch{}
lastExpeditionHistorySource=localStorage.getItem('muling:expeditions:history-source')||'';
try{expeditionMonth=JSON.parse(localStorage.getItem('muling:expeditions:last'))||null}catch{}
function normalizeExpeditionHistory(data){
 if(!data||data.source==='theory')return data;
 const amounts=[data.metal,data.crystal,data.deut],days=Number(data.count)/Number(data.perDay);
 if(!amounts.every(v=>Number.isFinite(v)&&v>=0)||!Number.isFinite(days)||days<=0)return data;
 const msu=amounts[0]+1.5*amounts[1]+3*amounts[2];
 const normalized={...data,source:data.source||'infinity',totalMsu:data.totalMsu??data.msu,msu,msuPerDay:msu/days,msuPerExpedition:msu/data.count};
 const ships=[data.shipMetal,data.shipCrystal,data.shipDeut];
 if(ships.every(v=>Number.isFinite(v)&&v>=0))normalized.shipsMsuPerDay=(ships[0]+1.5*ships[1]+3*ships[2])/days;
 return normalized;
}
function storeExpeditionHistory(data){
 if(!data||data.source==='theory')return;
 const source=data.source==='oglight'?'oglight':data.source==='manual'?'manual':'infinity';
 const normalized=normalizeExpeditionHistory({...data,source});
 expeditionHistories[source]=normalized;lastExpeditionHistorySource=source;
 if(expeditionMonth===data){expeditionMonth=normalized;localStorage.setItem('muling:expeditions:last',JSON.stringify(normalized))}
 localStorage.setItem('muling:expeditions:histories',JSON.stringify(expeditionHistories));
 localStorage.setItem('muling:expeditions:history-source',source);
}
for(const [source,data] of Object.entries(expeditionHistories))expeditionHistories[source]=normalizeExpeditionHistory(data);
// Migrate the still-active history from older versions without overwriting it with theory.
storeExpeditionHistory(expeditionMonth);
function updateExpeditionSourceControls(){
 const labels={infinity:'Infinity',oglight:'OGlight',manual:'Mois saisi à la main'},sources=Object.keys(labels).filter(source=>expeditionHistories[source]);
 const selector=$('exp-history-source');selector.innerHTML=sources.length?sources.map(source=>`<option value="${source}">${labels[source]}${expeditionHistories[source].month?` · ${esc(expeditionHistories[source].month)}`:''}</option>`).join(''):'<option value="">Aucun historique sauvegardé</option>';
 selector.disabled=!sources.length;selector.value=sources.includes(lastExpeditionHistorySource)?lastExpeditionHistorySource:(sources[0]||'');
 $('exp-manual-enabled').checked=expeditionMonth?.source==='theory';
 $('exp-source-status').textContent=expeditionMonth?.source==='theory'?(sources.length?'Estimation manuelle active. Décoche pour reprendre l’historique sauvegardé.':'Estimation manuelle active. Importe Infinity ou OGlight une fois pour pouvoir y revenir.'):(expeditionMonth?`${labels[expeditionMonth.source||'infinity']} utilisé pour les calculs.`:'Aucun historique actif. Importe Infinity ou choisis un mois OGlight.');
}
function restoreExpeditionHistory(source=lastExpeditionHistorySource){
 const saved=expeditionHistories[source];expeditionMonth=saved?normalizeExpeditionHistory({...saved}):null;
 if(saved){lastExpeditionHistorySource=source;localStorage.setItem('muling:expeditions:history-source',source)}
 localStorage.setItem('muling:expeditions:last',JSON.stringify(expeditionMonth));
 $('status').textContent=saved?'Historique sauvegardé réactivé':'Estimation manuelle désactivée : importe Infinity ou choisis un mois OGlight';
 render();renderOglightMonths();
}

try{oglightMonths=JSON.parse(localStorage.getItem('muling:oglight:months')||'[]')}catch{}
function parseOglightMonths(data){
 const stats=data?.stats;if(!stats||typeof stats!=='object'||Array.isArray(stats))throw Error('Sauvegarde OGlight attendue : données stats absentes');
 const months=new Map();
 for(const [key,day] of Object.entries(stats)){
  const match=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(key);if(!match||!day?.expe)continue;
  const [year,month,dayNumber]=match.slice(1).map(Number),date=new Date(Date.UTC(year,month-1,dayNumber));
  if(date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==dayNumber)continue;
  const count=Number(day.expe.count||0),gain=day.expe.gain||{};
  if(!Number.isSafeInteger(count)||count<0)continue;
  const values=['metal','crystal','deut'].map(k=>Number(gain[k]||0));
  if(values.some(v=>!Number.isFinite(v)))continue;
  const id=`${year}-${String(month).padStart(2,'0')}`,entry=months.get(id)||{month:id,count:0,metal:0,crystal:0,deut:0,lastDay:0};
  entry.lastDay=Math.max(entry.lastDay,dayNumber);
  entry.count+=count;for(let i=0;i<3;i++)entry[['metal','crystal','deut'][i]]+=values[i];months.set(id,entry);
 }
 const result=[...months.values()].filter(m=>m.count>0).sort((a,b)=>b.month.localeCompare(a.month));
 if(!result.length)throw Error('Aucune expédition datée trouvée dans cette sauvegarde OGlight');
 return result;
}
function useOglightMonth(m){
 const [year,month]=m.month.split('-').map(Number),calendarDays=new Date(year,month,0).getDate(),today=new Date(),current=year===today.getFullYear()&&month===today.getMonth()+1;
 const days=current?Math.min(today.getDate(),Math.max(1,m.lastDay||today.getDate())):calendarDays,msu=m.metal+1.5*m.crystal+3*m.deut;
 expeditionMonth={source:'oglight',month:m.month,start:`01.${String(month).padStart(2,'0')}.${year}`,end:`${String(days).padStart(2,'0')}.${String(month).padStart(2,'0')}.${year}`,count:m.count,metal:m.metal,crystal:m.crystal,deut:m.deut,msu,perDay:m.count/days,msuPerDay:msu/days,msuPerExpedition:msu/m.count};
 storeExpeditionHistory(expeditionMonth);localStorage.setItem('muling:expeditions:last',JSON.stringify(expeditionMonth));$('status').textContent=`Expéditions OGlight ${m.month} prises en compte`;render();renderOglightMonths();
}
function renderOglightMonths(){const box=$('oglight-months');if(!box)return;if(!oglightMonths.length){box.textContent='Importe la sauvegarde JSON depuis les réglages « Data » d’OGlight. Les mois seront affichés ici.';return}
 box.innerHTML=`<div class="oglight-months">${oglightMonths.map(m=>{const msu=m.metal+1.5*m.crystal+3*m.deut,[year,month]=m.month.split('-').map(Number),today=new Date(),current=year===today.getFullYear()&&month===today.getMonth()+1,days=current?Math.min(today.getDate(),Math.max(1,m.lastDay||today.getDate())):new Date(year,month,0).getDate(),selected=expeditionMonth?.source==='oglight'&&expeditionMonth.month===m.month;return `<div class="oglight-month"><b>${esc(m.month)}${current?' · en cours':''}</b><span>${fmt(m.count)} expéditions · ${fmtCost(msu)} USM trouvées · ${fmtCost(msu/days)} USM/jour</span><button type="button" data-oglight-month="${esc(m.month)}">${selected?'✓ Pris en compte':'Utiliser ce mois'}</button></div>`}).join('')}</div>`;
 box.querySelectorAll('[data-oglight-month]').forEach(button=>button.addEventListener('click',()=>{const m=oglightMonths.find(v=>v.month===button.dataset.oglightMonth);if(m)useOglightMonth(m)}));
}
$('oglight').addEventListener('change',async e=>{try{const data=JSON.parse(await e.target.files[0].text());oglightMonths=parseOglightMonths(data);localStorage.setItem('muling:oglight:months',JSON.stringify(oglightMonths));const today=new Date(),thisMonth=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}`;useOglightMonth(oglightMonths.find(m=>m.month!==thisMonth)||oglightMonths[0])}catch(err){$('status').textContent=`Import OGlight impossible : ${err.message}`}finally{e.target.value=''}});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Math.round(n).toLocaleString('fr-FR');
const fmtCost=n=>{const abs=Math.abs(n);const [factor,unit]=abs>=1e9?[1e9,'G']:abs>=1e6?[1e6,'M']:abs>=1e3?[1e3,'K']:[1,''];return unit?`${(n/factor).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})} ${unit}`:fmt(n)};
function amortissementText(item){const days=item?.days??item?.lastDays;if(!Number.isFinite(days))return ' · amortissement indisponible';const value=days.toLocaleString('fr-FR',{maximumFractionDigits:1});return item.stale?` · ${value} j (ancienne estimation du tableur)` : ['expedition-estimate','expedition-theory'].includes(item.source)?` · ${value} j estimés selon les expéditions`:` · ${value} j`}
renderOglightMonths();
function key(id){return `ogame-plan-v1:${account.playerId}:${id}`}
function cost(type,level){const base={1:[60,15,0,1.5],2:[48,24,0,1.6],3:[225,75,0,1.5]}[type],m=base[3]**(level-1);return [base[0]*m,base[1]*m,0]}
function productionEstimate(p,type){const level=Number(p.buildings?.[type]||0),original=account?.planets?.[p.id],baseLevel=Number(original?.buildings?.[type]||0),hour=Number(original?.production?.[{1:'metal',2:'crystal',3:'deuterium'}[type]]||0);if(level<1||baseLevel<1||hour<=0)return null;const shape=x=>x*Math.pow(1.1,x);return hour*(shape(level+1)-shape(level))/shape(baseLevel)}
function options(p,target){let out=[];for(let t=1;t<=3;t++){let level=Number(p.buildings?.[t]||0);if(level>=target[t])continue;const c=cost(t,level+1),msu=c[0]+c[1]*1.5+c[2]*3;const gain=productionEstimate(p,t);out.push({t,level,c,msu,gain,days:gain?msu/(gain*24*({1:1,2:1.5,3:3}[t])):Infinity})}return out.sort((a,b)=>a.days-b.days)[0]||null}
function reference(){const selected=planets.filter(p=>p.included);return [...selected].sort((a,b)=>[1,2,3].reduce((n,t)=>n+cost(t,Number(b.buildings?.[t]||0)+1)[0]-cost(t,Number(a.buildings?.[t]||0)+1)[0],0))[0]}
function publishMarkers(){if(!account||typeof chrome==='undefined'||!chrome.storage?.local)return;const selected=planets.filter(p=>p.included),ref=reference(),target={1:Math.max(0,...selected.map(p=>Number(p.buildings?.[1]||0))),2:Math.max(0,...selected.map(p=>Number(p.buildings?.[2]||0))),3:Math.max(0,...selected.map(p=>Number(p.buildings?.[3]||0)))};const byPlanet={};const freight=recyclerOptions(),topFreight=freight?.options.slice(0,4)||[];for(const p of planets){const mine=p.included?options(p,ref?.id===p.id?{1:target[1]+1,2:target[2]+1,3:target[3]+1}:target):null,lf=p.included?nextLf(p):null,building=p.included?nextBuilding(p):null,unlock=p.included?unlockNext(p):null;byPlanet[p.id]={included:p.included,freightTechs:topFreight.filter(x=>x.planetId===String(p.id)).map(x=>({id:x.techId,title:freightMarkerText(x,freight.capacity,freight.shipCost)})),freightRecycler:topFreight.find(x=>x.ship)?freightMarkerText(topFreight.find(x=>x.ship),freight.capacity,freight.shipCost):null,mineId:mine?String(mine.t):null,mineDays:Number.isFinite(mine?.days)?mine.days:null,lfId:lf?.id||null,lfDays:Number.isFinite(lf?.days??lf?.lastDays)?(lf.days??lf.lastDays):null,lfStale:!!lf?.stale,lfSource:lf?.source||null,buildingId:building?.id||null,buildingDays:Number.isFinite(building?.days??building?.lastDays)?(building.days??building.lastDays):null,buildingStale:!!building?.stale,unlockIds:unlock?.missing.map(x=>x.id)||[],unlockDetails:unlock?.missing.map(x=>({id:x.id,name:buildingNames?.[x.id]||`Bâtiment n° ${Number(x.id)%100}`,level:x.level,required:x.required,queued:x.queued}))||[]}}chrome.storage.local.set({mulingState:{playerId:String(account.playerId),playerName:account.playerName,exportedAt:account.exportedAt,planets:byPlanet,options:markerOptions}})}
function buildingThumb(id){const species=Math.floor(Number(id)/1000),slot=Number(id)%100;return species>=11&&species<=14&&slot>=1&&slot<=12?`<img src="icons/building-${id}.png" alt="">`:'<span class="building-fallback" aria-hidden="true">▣</span>'}
function referencePriorities(ref,target){if(!ref)return '';const snapshot=workbookReference?.planets?.[ref.id],valid=nextLf(ref)&&nextBuilding(ref)&&!nextLf(ref).stale&&!nextBuilding(ref).stale;const items=[];for(let t=1;t<=3;t++){const level=Number(ref.buildings?.[t]||0),c=cost(t,level+1),gain=productionEstimate(ref,t),days=gain?(c[0]+c[1]*1.5)/(gain*24*({1:1,2:1.5,3:3}[t])):Infinity;if(Number.isFinite(days))items.push({name:`Mine de ${names[t]} ${level} → ${level+1}`,days,icon:`<img src="icons/mine-${t}.png" alt="">`,note:'estimé'})}if(Number.isFinite(expeditionMonth?.msuPerDay))for(const x of expeditionLfCandidates(ref))items.push({name:`${x.tech.name} ${x.level} → ${x.level+1}`,days:x.days,icon:`<img src="icons/lf-${x.id}.png" alt="">`,note:'estimé'});if(valid)for(const item of snapshot.priorities||[]){const tech=lfCatalog?.[item.id];if(!Number.isFinite(expeditionMonth?.msuPerDay)&&item.kind==='lf'&&tech&&ref.selectedSpeciesTechnologyIds?.map(String).includes(item.id))items.push({name:`${tech.name} ${item.level} → ${item.level+1}`,days:item.days,icon:`<img src="icons/lf-${item.id}.png" alt="">`,note:'tableur'});if(item.kind==='building')items.push({name:`${item.name||'Bâtiment FDV'} ${item.level} → ${item.level+1}`,days:item.days,icon:buildingThumb(item.id),note:'tableur'})}return `<div class="priority-list">${items.sort((a,b)=>a.days-b.days).slice(0,6).map((x,i)=>`<div><span>${i+1}.</span>${x.icon}<span>${esc(x.name)}</span><b>${Math.round(x.days)} j</b><small>${x.note}</small></div>`).join('')}</div>`}
const raiderShips={
 202:{name:'Petit transporteur',base:5000,drive:115,civil:true,upgrade:{level:5,drive:117,base:10000}},
 203:{name:'Grand transporteur',base:7500,drive:115,civil:true,effects:['LC Boost']},
 204:{name:'Chasseur léger',base:12500,drive:115,effects:['LF Boost']},
 205:{name:'Chasseur lourd',base:10000,drive:117,effects:['HF Boost']},
 206:{name:'Croiseur',base:15000,drive:117,effects:['Cruiser Boost']},
 207:{name:'Vaisseau de bataille',base:10000,drive:118,effects:['Battleship Boost']},
 208:{name:'Vaisseau de colonisation',base:2500,drive:117,civil:true},
 209:{name:'Recycleur',base:2000,drive:115,civil:true,effects:['Recycler Boost'],upgrade:{level:17,drive:117,base:4000}},
 210:{name:'Sonde d’espionnage',base:100000000,drive:115,civil:true},
 211:{name:'Bombardier',base:4000,drive:117,upgrade:{level:8,drive:118,base:5000},effects:['Bomber Boost']},
 213:{name:'Destructeur',base:5000,drive:118,effects:['Destroyer Boost']},
 214:{name:'Étoile de la mort',base:100,drive:118,deathstar:true},
 215:{name:'Traqueur',base:10000,drive:118,effects:['BC Boost']},
 218:{name:'Faucheur',base:7000,drive:118},
 219:{name:'Éclaireur',base:12000,drive:118}
};
const driveInfo={115:{name:'Propulsion à combustion',base:[400,0,600],bonus:0.1},117:{name:'Propulsion à impulsion',base:[2000,4000,600],bonus:0.2},118:{name:'Propulsion hyperespace',base:[10000,20000,6000],bonus:0.3}};
const msu=c=>c[0]+c[1]*1.5+c[2]*3;
$('raider-ship').innerHTML=Object.entries(raiderShips).map(([id,ship])=>`<option value="${id}">${esc(ship.name)}</option>`).join('');
$('raider-ship').value=localStorage.getItem('muling:raider:ship')||'215';
if(!raiderShips[$('raider-ship').value])$('raider-ship').value='215';
$('raider-ship').addEventListener('change',e=>{localStorage.setItem('muling:raider:ship',e.target.value);renderRaider()});
const raiderPh=$('raider-ph'),raiderPlanet=$('raider-planet');
raiderPh.addEventListener('input',()=>{if(account&&/^\d+$/.test(raiderPh.value)){const ship=raiderShips[$('raider-ship').value],drive=ship.upgrade&&effectiveResearch(ship.upgrade.drive)>=ship.upgrade.level?ship.upgrade.drive:ship.drive;localStorage.setItem(`muling:drive:${account.playerId}:${drive}`,raiderPh.value);renderRaider()}});
raiderPlanet.addEventListener('change',()=>{localStorage.setItem('muling:raider:planet',raiderPlanet.value);renderRaider()});
function renderRaider(){
 const box=$('raider-results');if(!account||!lfCatalog){box.textContent='Importe ton compte pour comparer propulsion et FDV.';return}
 const included=planets.filter(p=>p.included),ship=raiderShips[$('raider-ship').value]||raiderShips[215],upgrade=ship.upgrade,drive=upgrade&&effectiveResearch(upgrade.drive)>=upgrade.level?upgrade.drive:ship.drive;
 const info=driveInfo[drive],level=Number(localStorage.getItem(`muling:drive:${account.playerId}:${drive}`)??effectiveResearch(drive)),base=drive===upgrade?.drive?upgrade.base:ship.base;
 $('raider-drive-label').textContent=`Niveau ${info.name}`;
 if(document.activeElement!==raiderPh)raiderPh.value=String(level);
 const savedPlanet=localStorage.getItem('muling:raider:planet'),oldPlanet=raiderPlanet.value;
 raiderPlanet.innerHTML=included.map(p=>`<option value="${p.id}">${esc(p.name)} [${p.galaxy}:${p.system}:${p.position}]</option>`).join('');
 const target=included.find(p=>String(p.id)===(oldPlanet||savedPlanet))||included.find(p=>p.selectedSpeciesId===703)||included[0];if(target)raiderPlanet.value=String(target.id);
 const rows=[{title:`${info.name} ${level} → ${level+1}`,gain:base*info.bonus,cost:info.base.map(n=>n*2**level)}];
 for(const p of included)for(const entry of activeLf(p)){
  const {id,tech,level:current,cost}=entry;
  if(!((tech.effect==='All Ship Speed'&&!ship.deathstar)||(tech.effect==='Civ Ship Speed'&&ship.civil)||ship.effects?.includes(tech.effect)))continue;
  rows.push({title:`${tech.name} ${current} → ${current+1} · ${p.name} [${p.galaxy}:${p.system}:${p.position}]`,gain:base*Number(tech.bonusPerLevel||0)/100,cost});
 }
 rows.sort((a,b)=>(b.gain/msu(b.cost))-(a.gain/msu(a.cost)));
 const future=target?Object.entries(lfCatalog).filter(([id,tech])=>Number(tech.slot)>12&&!Number(target.speciesResearches?.[id]||0)&&((tech.effect==='All Ship Speed'&&!ship.deathstar)||(tech.effect==='Civ Ship Speed'&&ship.civil)||ship.effects?.includes(tech.effect))).map(([id,tech])=>({id,tech,cost:tech.base})):[];
 const transition=upgrade&&drive!==upgrade.drive?`<small>Au niveau ${upgrade.level} de propulsion à impulsion, ce vaisseau change de moteur et de vitesse de base.</small>`:'';
 box.innerHTML=`<p>Gain brut du prochain niveau pour ${esc(ship.name)}. ${info.name} ${level} : ${fmt(base*(1+level*info.bonus))} de vitesse avant bonus FDV et de classe.</p><div class="raider-table">${rows.map(x=>`<div><b>${esc(x.title)}</b><span>+${fmt(x.gain)} vitesse</span><span>${fmtCost(msu(x.cost))} USM</span><strong>${(x.gain/msu(x.cost)*1e6).toLocaleString('fr-FR',{maximumFractionDigits:1})} vitesse / M USM</strong></div>`).join('')}</div>${transition}${future.length?`<div class="future-tech"><b>FDV encore à débloquer sur ${esc(target.name)}</b>${future.map(x=>`<div>${esc(x.tech.name)} (T${Math.ceil(x.tech.slot/6)}-${(x.tech.slot-1)%6+1}) : premier niveau +${fmt(base*Number(x.tech.bonusPerLevel||0)/100)} vitesse brute · ${fmtCost(msu(x.cost))} USM de recherche. Coût du déblocage à ajouter.</div>`).join('')}</div>`:''}<small>Comparaison des prochains niveaux sur les planètes cochées. La vitesse réelle dépend aussi des bonus de classe, bâtiments et événements.</small>`;
}
const recyclerCount=$('recycler-count');
recyclerCount.addEventListener('input',()=>{renderRecycler();publishMarkers()});
function storedRecyclerCount(){return storedShipCount(209)}
function recyclerOptions(){
 if(!account||!lfCatalog)return null;
 const count=Number(recyclerCount.value);if(!Number.isSafeInteger(count)||count<0)return null;
 const hyper=effectiveResearch(114),base=20000,shipCost=[10000,6000,2000];
 const entries=planets.filter(p=>p.included).flatMap(p=>activeLf(p).filter(x=>['Recycler Boost','Civ Ship Capacity'].includes(x.tech.effect)).map(x=>({...x,planet:p})));
 const bonus=entries.reduce((n,x)=>n+Number(x.tech.bonusPerLevel||0)*x.level/100,0);
 const capacity=base*(1+hyper*0.05+bonus),hyperCost=[0,4000,2000].map(n=>n*2**hyper);
 const options=[{title:`Technologie hyperespace ${hyper} → ${hyper+1}`,gain:count*base*0.05,cost:hyperCost}];
 for(const x of entries)options.push({title:`${x.tech.name} ${x.level} → ${x.level+1} · ${x.planet.name} [${x.planet.galaxy}:${x.planet.system}:${x.planet.position}]`,gain:count*base*Number(x.tech.bonusPerLevel||0)/100,cost:x.cost,planetId:String(x.planet.id),techId:String(x.id)});
 options.push({title:'Construire 1 recycleur',gain:capacity,cost:shipCost,ship:true});
 options.sort((a,b)=>b.gain/msu(b.cost)-a.gain/msu(a.cost));
 return {count,capacity,shipCost,options};
}
function freightMarkerText(x,capacity,shipCost){
 const cost=msu(x.cost),sameBudget=Math.floor(cost/msu(shipCost));
 return `${x.title} · +${fmt(x.gain)} fret${x.ship?'':' sur la flotte'} · ${fmtCost(cost)} USM · ${fmtCost(x.gain/cost*1e6)} fret / M USM${x.ship?'':` · Au même budget : ${fmt(sameBudget)} recycleurs, soit +${fmt(sameBudget*capacity)} fret`}`;
}
function renderRecycler(){
 const box=$('recycler-results'),data=recyclerOptions();
 if(!data){box.textContent=account?'Indique un nombre entier de recycleurs.':'Importe ton compte pour comparer le fret.';return}
 const {count,capacity,shipCost,options}=data,best=options[0],selectedCount=planets.filter(p=>p.included).length;
 box.innerHTML=`${!selectedCount?'<p class="note">Aucune planète fixe cochée : les technologies FDV ne peuvent pas être classées. Coche tes colonies dans la liste au-dessus.</p>':''}<p>${fmt(count)} recycleurs · fret estimé ${fmt(capacity)} par recycleur. Meilleur gain de fret par ressource : <strong>${esc(best.title)}</strong>.</p><div class="raider-table">${options.map(x=>`<div><b>${esc(x.title)}</b><span>+${fmt(x.gain)} fret${x.ship?'':' sur la flotte'}</span><span>${fmtCost(msu(x.cost))} USM</span><strong>${fmtCost(x.gain/msu(x.cost)*1e6)} fret / M USM</strong>${x.ship?'':`<small>Au même budget : ${fmt(Math.floor(msu(x.cost)/msu(shipCost)))} recycleurs, soit +${fmt(Math.floor(msu(x.cost)/msu(shipCost))*capacity)} fret.</small>`}</div>`).join('')}</div><small>Estimation sur le fret des recycleurs indiqués ; la technologie hyperespace profite aussi aux autres vaisseaux. Les bonus de classe, bâtiments, officiers et événements ne sont pas inclus. Les recherches FDV affichées sont celles déjà sélectionnées et montées sur les planètes cochées.</small>`;
}
const combatShips={
 202:{name:'Petit transporteur',cost:[2000,2000,0],attack:5,shield:10},
 203:{name:'Grand transporteur',cost:[6000,6000,0],attack:5,shield:25},
 204:{name:'Chasseur léger',cost:[3000,1000,0],attack:50,shield:10},
 205:{name:'Chasseur lourd',cost:[6000,4000,0],attack:150,shield:25},
 206:{name:'Croiseur',cost:[20000,7000,2000],attack:400,shield:50},
 207:{name:'Vaisseau de bataille',cost:[45000,15000,0],attack:1000,shield:200},
 208:{name:'Vaisseau de colonisation',cost:[10000,20000,10000],attack:50,shield:100},
 209:{name:'Recycleur',cost:[10000,6000,2000],attack:1,shield:10},
 210:{name:'Sonde',cost:[0,1000,0],attack:0,shield:0},
 211:{name:'Bombardier',cost:[50000,25000,15000],attack:1000,shield:500},
 213:{name:'Destructeur',cost:[60000,50000,15000],attack:2000,shield:500},
 214:{name:'Étoile de la mort',cost:[5000000,4000000,1000000],attack:200000,shield:50000},
 215:{name:'Traqueur',cost:[30000,40000,15000],attack:700,shield:400},
 218:{name:'Faucheur',cost:[85000,55000,20000],attack:2800,shield:700},
 219:{name:'Éclaireur',cost:[8000,15000,8000],attack:200,shield:100}
};
for(const ship of Object.values(combatShips))ship.hull=(ship.cost[0]+ship.cost[1])/10;
const combatTechs={109:{name:'Armes',key:'attack',unit:'attaque',base:[800,200,0]},110:{name:'Bouclier',key:'shield',unit:'bouclier',base:[200,600,0]},111:{name:'Protection',key:'hull',unit:'coque',base:[1000,0,0]}};
const combatShip=$('combat-ship'),combatTech=$('combat-tech'),combatCount=$('combat-count');
combatShip.innerHTML=`<option value="all">Tous les vaisseaux</option>`+Object.entries(combatShips).map(([id,ship])=>`<option value="${id}">${esc(ship.name)}</option>`).join('');
let fleetApi=null;
function fleetKey(){return `muling:fleet:${account?.playerId||'local'}`}
function parseFleetApi(raw){
 const entries=raw.trim().split('|').filter(Boolean),ships={},researches={};
 if(!entries.length)throw Error('API flotte vide');
 for(const entry of entries){const match=/^(characterClassId|\d+);(\d+)$/.exec(entry.trim());if(!match)throw Error(`Ligne invalide : ${entry.slice(0,40)}`);const [,id,value]=match,n=Number(value);if(!Number.isSafeInteger(n))throw Error('Nombre hors limites');if(combatShips[id])ships[id]=n;else if([109,110,111,114,115,117,118].includes(Number(id)))researches[id]=n}
 if(!Object.keys(ships).length)throw Error('Aucun vaisseau reconnu dans cette API');
 return {ships,researches,importedAt:Date.now()};
}
function effectiveResearch(id){return Number(fleetApi?.researches?.[id]??account?.researches?.[id]??0)}
function storedShipCount(id){if(fleetApi?.ships&&Object.hasOwn(fleetApi.ships,id))return fleetApi.ships[id];return [...Object.values(account?.planets||{}),...Object.values(account?.moons||{})].reduce((sum,p)=>sum+Number(p.ships?.[id]||0),0)}
function setFleetApi(data){fleetApi=data;combatCount.value=combatShip.value==='all'?'':String(storedShipCount(combatShip.value));recyclerCount.value=String(storedRecyclerCount());renderCombat();renderRecycler();renderRaider();publishMarkers()}
$('fleet-api-import').addEventListener('click',()=>{try{const data=parseFleetApi($('fleet-api').value);localStorage.setItem(fleetKey(),JSON.stringify(data));setFleetApi(data);$('fleet-api-status').textContent=`Flotte importée : ${Object.keys(data.ships).length} types de vaisseaux · recherches synchronisées.`}catch(e){$('fleet-api-status').textContent=`Import impossible : ${e.message}`}});
combatShip.value=localStorage.getItem('muling:combat:ship')||'215';combatTech.value=localStorage.getItem('muling:combat:tech')||'109';
combatShip.addEventListener('change',()=>{localStorage.setItem('muling:combat:ship',combatShip.value);combatCount.value=combatShip.value==='all'?'':storedShipCount(combatShip.value);renderCombat()});
combatTech.addEventListener('change',()=>{localStorage.setItem('muling:combat:tech',combatTech.value);renderCombat()});
combatCount.addEventListener('input',renderCombat);
function combatLfEntries(id){
 const effects=raiderShips[id]?.effects||[];
 return lfCatalog&&account?planets.filter(p=>p.included).flatMap(p=>activeLf(p).filter(x=>effects.includes(x.tech.effect)).map(x=>({...x,planet:p}))):[];
}
function combatLfBonus(id){return combatLfEntries(id).reduce((sum,x)=>sum+x.level*Number(x.tech.bonusPerLevel||0)/100,0)}
function renderCombat(){
 const box=$('combat-results');if(!account&&!fleetApi){box.textContent='Importe ton compte ou ton API flotte pour comparer.';return}
 const all=combatShip.value==='all',tech=combatTechs[combatTech.value],level=effectiveResearch(combatTech.value);
 const eligible=Object.entries(combatShips).filter(([id,s])=>s[tech?.key]>0&&[204,205,206,207,211,213,214,215,218,219].includes(Number(id)));
 const candidate=all?eligible.sort((a,b)=>b[1][tech.key]*(1+0.1*level+combatLfBonus(b[0]))/msu(b[1].cost)-a[1][tech.key]*(1+0.1*level+combatLfBonus(a[0]))/msu(a[1].cost))[0]:[combatShip.value,combatShips[combatShip.value]];
 const ship=candidate?.[1],shipId=candidate?.[0],count=all?Object.keys(combatShips).reduce((sum,id)=>sum+storedShipCount(id),0):Number(combatCount.value);
 if(!ship||!tech||!Number.isSafeInteger(count)||count<0||level>50){box.textContent='Indique un nombre entier de vaisseaux et un niveau de recherche valide.';return}
 const costs=tech.base.map(v=>v*2**level),techMsu=msu(costs),shipsWithBudget=Math.floor(techMsu/msu(ship.cost)),base=ship[tech.key],bonus=combatLfBonus(shipId);
 const newShipsGain=shipsWithBudget*base*(1+0.1*level+bonus);
 const fleetBase=Object.entries(combatShips).reduce((sum,[id,s])=>sum+storedShipCount(id)*s[tech.key],0);
 const techGain=(all?fleetBase:count*base)*0.1,scope=all?`${fmt(count)} vaisseaux · flotte entière`:`${fmt(count)} ${esc(ship.name)}${count>1?'s':''}`;
 const lfOptions=all?[]:combatLfEntries(shipId).map(x=>({title:`${x.tech.name} ${x.level} → ${x.level+1} · ${x.planet.name} [${x.planet.galaxy}:${x.planet.system}:${x.planet.position}]`,gain:count*base*Number(x.tech.bonusPerLevel||0)/100,cost:msu(x.cost)})).filter(x=>x.cost>0).sort((a,b)=>b.gain/b.cost-a.gain/a.cost);
 const options=[{label:`${tech.name} ${level} → ${level+1}`,gain:techGain,cost:techMsu},{label:`Construire ${fmt(shipsWithBudget)} ${ship.name}`,gain:newShipsGain,cost:techMsu},...lfOptions.map(x=>({label:x.title,gain:x.gain,cost:x.cost}))];
 const best=[...options].sort((a,b)=>b.gain/b.cost-a.gain/a.cost)[0];
 box.innerHTML=`<p><b>${scope}</b> · ${esc(tech.name)} ${level} → ${level+1} · ${fmtCost(techMsu)} USM${!all&&bonus?` · bonus FDV ${fmt(bonus*100)} % sur les ${esc(ship.name)}s`:''}</p><div class="combat-comparison"><div><b>Augmenter ${esc(tech.name)}</b><strong>+${fmt(techGain)} ${tech.unit}</strong><small>Sur ${scope} · coût ${fmtCost(techMsu)} USM</small><small>${fmtCost(techGain/techMsu*1e6)} ${tech.unit} / M USM</small></div><div><b>Construire des ${esc(ship.name)}s</b><strong>+${fmt(newShipsGain)} ${tech.unit}</strong><small>${fmt(shipsWithBudget)} vaisseaux au même budget${all?' · meilleur rendement brut parmi les vaisseaux de combat':''}</small><small>${fmtCost(newShipsGain/techMsu*1e6)} ${tech.unit} / M USM</small></div></div>${lfOptions.length?`<div class="raider-table combat-lf"><b>Prochains niveaux FDV pour les ${esc(ship.name)}s</b>${lfOptions.map(x=>`<div><b>${esc(x.title)}</b><span>+${fmt(x.gain)} ${tech.unit} sur la flotte sélectionnée</span><span>${fmtCost(x.cost)} USM</span><strong>${fmtCost(x.gain/x.cost*1e6)} ${tech.unit} / M USM</strong></div>`).join('')}</div>`:''}<p>Meilleur gain de ${tech.unit} par ressource : <strong>${esc(best.label)}</strong>.</p><small>Les niveaux FDV sélectionnés sur les planètes cochées sont cumulés pour tous les vaisseaux de ce type. Estimation additive des bonus bruts, sans simulation de combat, tirs rapides, pertes, expérience des formes de vie ni autres bonus.</small>`;
}
function render(){refreshDailyExpeditions();const selected=planets.filter(p=>p.included),ref=reference(),astro=astroCapacity();$('count').textContent=`${selected.length} / ${planets.length} incluses`;if(!planets.length){$('planets').innerHTML='';renderRaider();renderCombat();renderRecycler();return}const target={1:Math.max(...selected.map(p=>p.buildings?.[1]||0),0),2:Math.max(...selected.map(p=>p.buildings?.[2]||0),0),3:Math.max(...selected.map(p=>p.buildings?.[3]||0),0)};
 $('summary').innerHTML=(selected.length?`<strong>Vos prochaines améliorations les plus rentables, à partir de la colonie la plus évoluée.</strong><br>Colonie de référence : ${esc(ref.name)} [${ref.galaxy}:${ref.system}:${ref.position}]. Les autres colonies reçoivent leur conseil selon leurs propres niveaux.`:'<strong>Sélectionne les planètes fixes à prendre en compte.</strong> Les volantes peuvent rester décochées.')+referencePriorities(ref,target)+(expeditionMonth?.source==='theory'?`<br><br><strong>Estimation des expéditions · économie ×${expeditionMonth.economy}</strong><br>${fmt(expeditionMonth.perDay)} expéditions/jour · ${fmtCost(expeditionMonth.msuPerDay)} USM/jour en ressources · ${fmtCost(expeditionMonth.shipsMsuPerDay)} USM/jour en vaisseaux.`:expeditionMonth?`<br><br><strong>Expéditions : ${fmt(expeditionMonth.count)} (${esc(expeditionMonth.start)} au ${esc(expeditionMonth.end)})</strong><br>Environ ${fmt(expeditionMonth.perDay)} expéditions/jour · ${fmtCost(expeditionMonth.msuPerDay)} USM/jour en ressources · ${fmtCost(expeditionMonth.msuPerExpedition)} USM/expédition${Number.isFinite(expeditionMonth.shipsMsuPerDay)?` · ${fmtCost(expeditionMonth.shipsMsuPerDay)} USM/jour en vaisseaux`:''}. ${expeditionMonth.source==='manual'?'Mois complet saisi à la main ; ressources trouvées uniquement.':expeditionMonth.source==='oglight'?'Historique OGlight ; ressources trouvées uniquement.':'Historique Infinity ; ressources et flotte trouvées valorisées séparément.'}`:'');
 $('planets').innerHTML=planets.map(p=>{let mine=p.included?options(p,ref?.id===p.id?{1:target[1]+1,2:target[2]+1,3:target[3]+1}:target):null;let next=p.included?nextLf(p):null;let building=p.included?nextBuilding(p):null,unlock=p.included?unlockNext(p):null;let title=mine?`${names[mine.t]} ${mine.level} → ${mine.level+1}`:'Profil minier atteint';let detail=mine?`${resource(mine.c[0],'metal')} · ${resource(mine.c[1],'crystal')}${Number.isFinite(mine.days)?` · ${mine.days.toLocaleString('fr-FR',{maximumFractionDigits:1})} j estimés`:''}`:'Aucun retard sur le profil cible';return `<article class="card ${p.included?'':'excluded'} ${ref?.id===p.id?'reference':''}"><div class="top"><div><h2>${esc(p.name||'Colonie')} ${ref?.id===p.id?'★':''}</h2><span class="coord">[${p.galaxy}:${p.system}:${p.position}]</span></div><label class="switch"><input type="checkbox" data-id="${p.id}" ${p.included?'checked':''}> Inclure</label></div>${p.included?unlockChoices(p):''}${unlock?`<div class="unlock-status">${unlock.done?`Palier T${Math.ceil(unlock.slot/6)}-${(unlock.slot-1)%6+1} ${unlock.planned?"planifié dans la file : attendre la fin des constructions":"atteint pour les bâtiments du tableur"}. Vérifie la population effective dans OGame.`:`🔵 T${Math.ceil(unlock.slot/6)}-${(unlock.slot-1)%6+1} : ${unlock.missing.length} bâtiment${unlock.missing.length>1?'s':''} à monter · ${unlock.missing.map(x=>`${esc(buildingNames?.[x.id]||`Bâtiment n° ${Number(x.id)%100}`)} ${x.level}/${x.required}${x.queued>x.level?` (niveau ${x.queued} en construction)`:""}`).join(' · ')}.`}</div>`:''}<div class="levels"><span class="stat">M ${p.buildings?.[1]||0}</span><span class="stat">C ${p.buildings?.[2]||0}</span><span class="stat">D ${p.buildings?.[3]||0}</span></div>${p.included?`<div class="recommend"><div class="icon">${mine?`<img src="icons/mine-${mine.t}.png" alt="">`:"⛏"}<i class="plus">+</i></div><div><b>Mine : ${title}</b><small>${detail}</small></div></div><div class="recommend"><div class="icon">${next?`<img src="icons/lf-${next.id}.png" alt="">`:"◇"}</div><div>${next?`<b>FDV : ${esc(next.id==='14205'?'Technologie de détection améliorée':next.tech.name)} ${next.level} → ${next.level+1}</b><small>${resource(next.cost[0],'metal')} · ${resource(next.cost[1],'crystal')} · ${resource(next.cost[2],'deuterium')}${amortissementText(next)}</small>`:`<b>FDV : calcul à actualiser</b><small>Niveau modifié : classement FDV à recalculer pour ce nouvel état.</small>`}</div></div>${building?`<div class="recommend"><div class="icon">${buildingThumb(building.id)}</div><div><b>Bâtiment FDV : ${esc(building.name)} ${building.level} → ${building.level+1}</b><small>${building.stale?`Ancien calcul du tableur${amortissementText(building)}`:`${resource(building.cost[0],'metal')} · ${resource(building.cost[1],'crystal')} · ${resource(building.cost[2],'deuterium')}${amortissementText(building)}`}</small></div></div>`:''}`:'<small>Exclue des calculs et des recommandations.</small>'}</article>`}).join('');
 document.querySelectorAll('[data-goal]').forEach(el=>el.addEventListener('change',()=>{const p=planets.find(p=>String(p.id)===el.dataset.goal);if(!p)return;localStorage.setItem(goalKey(p),el.value);render()}));document.querySelectorAll('[data-id]').forEach(el=>el.addEventListener('change',()=>{let p=planets.find(p=>String(p.id)===el.dataset.id);p.included=el.checked;localStorage.setItem(key(p.id),String(el.checked));render()}));publishMarkers();renderRaider();renderRecycler();if(!combatCount.value)combatCount.value=combatShip.value==='all'?'':storedShipCount(combatShip.value);renderCombat()}
let liveLevels={};
function loadAccount(data,savedState=null){account=data;planets=Object.values(data.planets).map(p=>({...p,included:(localStorage.getItem(key(p.id))??(String(savedState?.playerId)===String(data.playerId)?String(savedState?.planets?.[p.id]?.included):null))==='true'})).sort((a,b)=>a.galaxy-b.galaxy||a.system-b.system||a.position-b.position);applyLiveLevels();try{fleetApi=JSON.parse(localStorage.getItem(fleetKey())||'null')}catch{fleetApi=null}recyclerCount.value=String(storedRecyclerCount());combatCount.value=combatShip.value==='all'?'':String(storedShipCount(combatShip.value));render()}
function applyLiveLevels(){if(!account)return;let changed=false;const exported=Date.parse(account.exportedAt)||0;for(const p of planets){const live=liveLevels[`${account.playerId}:${p.id}`];if(!live||live.capturedAt<=exported)continue;for(const field of ['buildings','speciesResearches','speciesBuildings']){if(!live[field])continue;const before=JSON.stringify(p[field]||{});p[field]={...(p[field]||{}),...live[field]};if(JSON.stringify(p[field])!==before)changed=true}if(Array.isArray(live.selectedSpeciesTechnologyIds)){const selected=live.selectedSpeciesTechnologyIds.map(String);if(JSON.stringify(p.selectedSpeciesTechnologyIds||[])!==JSON.stringify(selected))changed=true;p.selectedSpeciesTechnologyIds=selected;}if(Object.hasOwn(live,'pendingResearch'))p.pendingResearch=live.pendingResearch;if(Object.hasOwn(live,'pendingBuildings'))p.pendingBuildings=live.pendingBuildings;if(live.researches)for(const [id,level] of Object.entries(live.researches))account.researches[id]=Math.max(Number(account.researches[id]||0),Number(level))}if(changed)$('status').textContent='Niveaux actualisés depuis OGame · calcul FDV à réactualiser après un changement de niveau'}
chrome.storage.local.get(['mulingAccount','mulingLiveLevels','mulingState'],data=>{liveLevels=data.mulingLiveLevels||{};if(data.mulingAccount){loadAccount(data.mulingAccount,data.mulingState);$('status').textContent='Compte restauré · niveaux synchronisés depuis les pages OGame visitées'}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local'||!changes.mulingLiveLevels)return;liveLevels=changes.mulingLiveLevels.newValue||{};if(account){applyLiveLevels();render()}});
$('file').addEventListener('change',async e=>{try{let d=JSON.parse(await e.target.files[0].text());if(d.schemaVersion!==1||!d.playerId||!d.planets||typeof d.planets!=='object')throw Error('Format Origin Exporter version 1 attendu');loadAccount(d);chrome.storage.local.set({mulingAccount:d});$('status').textContent=`Export du ${new Date(d.exportedAt).toLocaleString('fr-FR')}`;render()}catch(err){$('status').textContent=`Import impossible : ${err.message}`}});
function readInfinityHistory(doc){
 // Saved HTML can lose the overlay's active CSS class. Read the data itself.
 const content=doc.querySelector('.ogk-stats-content')||doc;
 const dates=[...content.querySelectorAll('.ogk-date strong')].map(x=>x.textContent.trim());
 const global=content.querySelector('.ogk-global .ogk-center');
 const grid=content.querySelector('.ogk-grid.ogk-am')||content.querySelector('.ogk-grid');
 if(!grid||!global||dates.length!==2)throw Error('Le fichier HTML ne contient pas les statistiques d’expédition. Ouvre Infinity → Expéditions, sélectionne septembre, puis enregistre à nouveau la page en HTML.');
 const parseNumber=value=>{if(value==null||String(value).trim()==='')return NaN;const text=String(value).trim().replace(/\s/g,'');if(!/^[\d.,]+$/.test(text))return NaN;return Number(text.replaceAll('.','').replace(',','.'))};
 const count=parseNumber(global.textContent);
 const rows=[...grid.querySelectorAll('p')];
 const readRow=label=>{const row=rows.find(x=>x.textContent.trim()===label);if(!row)return null;const cells=[...row.parentElement.children],i=cells.indexOf(row);return cells.slice(i+1,i+4).map(x=>parseNumber(x.getAttribute('data-title')??x.getAttribute('title')))};
 const resources=readRow('Ressources');
 const date=value=>{const match=/^(\d{2})\.(\d{2})\.(\d{2}|\d{4})$/.exec(value);if(!match)return NaN;const [,dd,mm,yy]=match,y=yy.length===2?2000+Number(yy):Number(yy),stamp=Date.UTC(y,Number(mm)-1,Number(dd)),check=new Date(stamp);return check.getUTCFullYear()===y&&check.getUTCMonth()===Number(mm)-1&&check.getUTCDate()===Number(dd)?stamp:NaN};
 const days=Math.round((date(dates[1])-date(dates[0]))/86400000)+1;
 if(!Number.isSafeInteger(count)||count<1||!Number.isFinite(days)||days<1||resources?.length!==3||resources.some(n=>!Number.isFinite(n)||n<0))throw Error('Les dates, le nombre d’expéditions ou les montants de la ligne Ressources sont incomplets dans le HTML.');
 const [metal,crystal,deut]=resources,msu=metal+1.5*crystal+3*deut;
 const history={source:'infinity',start:dates[0],end:dates[1],count,metal,crystal,deut,msu,perDay:count/days,msuPerDay:msu/days,msuPerExpedition:msu/count};
 const fleet=readRow('Flotte');if(fleet?.length===3&&fleet.every(n=>Number.isFinite(n)&&n>=0))[history.shipMetal,history.shipCrystal,history.shipDeut]=fleet;
 return normalizeExpeditionHistory(history);
}
$('infinity').addEventListener('change',async e=>{
 const input=e.target;if(!input.files?.[0])return;
 try{
  const doc=new DOMParser().parseFromString(await input.files[0].text(),'text/html'),history=readInfinityHistory(doc);
  // Replace the active source only after the whole file has been validated.
  expeditionMonth=history;
  const [dd,mm,yy]=history.start.split('.');$('exp-month').value=`${yy.length===2?'20'+yy:yy}-${mm}`;$('exp-count').value=String(history.count);$('exp-unit').value='1000000000';
  for(const [id,key] of [['exp-metal','metal'],['exp-crystal','crystal'],['exp-deut','deut']])$(id).value=String(history[key]/1e9).replace('.',',');
  storeExpeditionHistory(history);localStorage.setItem('muling:expeditions:last',JSON.stringify(expeditionMonth));render();renderOglightMonths();
  $('status').textContent=`Infinity importé : ${history.start} → ${history.end} · ${fmt(history.count)} expéditions · ${fmtCost(history.msuPerDay)} USM/jour en ressources`;
 }catch(err){$('status').textContent=`Import Infinity impossible : ${err.message} Les données précédentes restent utilisées.`}
 finally{input.value=''}
});

$('expedition-form').addEventListener('submit',e=>{e.preventDefault();const month=$('exp-month').value,count=Number($('exp-count').value),unit=Number($('exp-unit').value);const parse=id=>{const value=$(id).value.trim().replace(/\s/g,'').replace(',','.');return /^\d+(?:\.\d+)?$/.test(value)?Number(value)*unit:NaN};const metal=parse('exp-metal'),crystal=parse('exp-crystal'),deut=parse('exp-deut');const [year,m]=month.split('-').map(Number),days=new Date(year,m,0).getDate();if(!year||!m||!Number.isInteger(count)||count<1||[metal,crystal,deut].some(n=>!Number.isFinite(n)||n<0)){$('status').textContent='Vérifie le mois et les montants saisis';return}const msu=metal+crystal*1.5+deut*3;expeditionMonth={source:'manual',start:`01.${String(m).padStart(2,'0')}.${year}`,end:`${days}.${String(m).padStart(2,'0')}.${year}`,count,metal,crystal,deut,msu,perDay:count/days,msuPerDay:msu/days,msuPerExpedition:msu/count};storeExpeditionHistory(expeditionMonth);localStorage.setItem('muling:expeditions:last',JSON.stringify(expeditionMonth));$('status').textContent='Mois d’expéditions enregistré';render();renderOglightMonths()});

if(expeditionMonth?.metal!=null){const [,mm,yyyy]=expeditionMonth.start.split('.');$('exp-month').value=`${yyyy}-${mm}`;$('exp-count').value=expeditionMonth.count;$('exp-unit').value='1000000000';for(const [id,key] of [['exp-metal','metal'],['exp-crystal','crystal'],['exp-deut','deut']])$(id).value=String(expeditionMonth[key]/1e9).replace('.',',');}

$('expedition-daily-form').addEventListener('submit',e=>{
 e.preventDefault();const perDay=Number($('exp-daily').value),economy=Number($('exp-economy').value),topBase=Number($('exp-top').value),booster=Number($('exp-booster').value);
 if(!Number.isFinite(perDay)||perDay<=0||!Number.isInteger(economy)||economy<1||economy>100||!Number.isFinite(booster)||booster<0||booster>1000){$('status').textContent='Vérifie les paramètres des expéditions';return}
 dailyExpeditionSettings={perDay,economy,topBase,booster};localStorage.setItem('muling:expeditions:daily',JSON.stringify(dailyExpeditionSettings));
 storeExpeditionHistory(expeditionMonth);
 expeditionMonth={source:'theory',...dailyExpeditionSettings};localStorage.setItem('muling:expeditions:last',JSON.stringify(expeditionMonth));$('status').textContent='Estimation quotidienne activée';render();renderOglightMonths();
});
if(dailyExpeditionSettings){for(const [id,key] of [['exp-daily','perDay'],['exp-economy','economy'],['exp-top','topBase'],['exp-booster','booster']])$(id).value=dailyExpeditionSettings[key]??(key==='economy'?5:key==='topBase'?50000:0)}

$('exp-manual-enabled').addEventListener('change',e=>{
 if(!e.target.checked){restoreExpeditionHistory($('exp-history-source').value);return}
 if(!dailyExpeditionSettings){e.target.checked=false;$('status').textContent='Renseigne ta moyenne et clique sur « Utiliser cette estimation »';return}
 storeExpeditionHistory(expeditionMonth);expeditionMonth={source:'theory',...dailyExpeditionSettings};localStorage.setItem('muling:expeditions:last',JSON.stringify(expeditionMonth));
 $('status').textContent='Estimation quotidienne réactivée';render();renderOglightMonths();
});
$('exp-history-source').addEventListener('change',e=>restoreExpeditionHistory(e.target.value));
updateExpeditionSourceControls();
