// Read-only navigation entry point; no game data is changed.
function addMulingMenu() {
  const menu = document.querySelector('#menuTable');
  if (!menu || document.querySelector('#muling-menu-entry')) return;
  const li = document.createElement('li');
  li.id = 'muling-menu-entry';
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'menubutton';
  button.textContent = 'Muling';
  button.title = 'Ouvrir le tableau Muling';
  button.addEventListener('click', () => chrome.runtime.sendMessage({type:'openMuling'}));
  li.append(button);
  // Keep it next to the other tools added at the foot of the menu.
  menu.append(li);
}
addMulingMenu();
let markerState = null;
function currentPlanetId() {
  const active = document.querySelector('#planetList .smallplanet.hightlightPlanet[id^="planet-"]');
  return active?.id.slice(7) || document.querySelector('meta[name="ogame-planet-id"]')?.content || new URLSearchParams(location.search).get('cp');
}
function updateMarkers() {
  const playerId = document.querySelector('meta[name="ogame-player-id"]')?.content;
  const planet = markerState?.planets?.[currentPlanetId()];
  const component = new URLSearchParams(location.search).get('component');
  const id = playerId === markerState?.playerId && planet?.included
    ? component === 'supplies' && markerState.options?.mine !== false ? planet.mineId : component === 'lfresearch' && markerState.options?.lf !== false ? planet.lfId : component === 'lfbuildings' && markerState.options?.building ? planet.buildingId : null
    : null;
  const icon = id ? document.querySelector(`li.technology[data-technology="${CSS.escape(String(id))}"] .icon`) : null;
  const days = component === 'supplies' ? planet?.mineDays : component === 'lfresearch' ? planet?.lfDays : planet?.buildingDays;
  const stale = component === 'lfresearch' ? planet?.lfStale : component === 'lfbuildings' ? planet?.buildingStale : false;
  const amortissement = Number.isFinite(days) && days >= 0
    ? `${stale ? 'Dernière estimation (niveaux modifiés)' : 'Amortissement estimé'} : ${days.toLocaleString('fr-FR', {maximumFractionDigits:1})} jours${component === 'supplies' ? ' (estimation des mines)' : component === 'lfresearch' && planet?.lfSource === 'expedition-estimate' ? ' (historique des expéditions)' : component === 'lfresearch' && planet?.lfSource === 'expedition-theory' ? ' (estimation quotidienne des expéditions)' : ''}`
    : 'Amortissement indisponible pour cette amélioration';
  for (const marker of document.querySelectorAll('.muling-game-plus')) {
    if (marker.parentElement !== icon) {
      marker.parentElement?.classList.remove('muling-marked-icon');
      marker.remove();
    }
  }
  if (icon && !icon.querySelector('.muling-game-plus')) {
    icon.classList.add('muling-marked-icon');
    const marker = document.createElement('span');
    marker.className = 'muling-game-plus';
    marker.textContent = '+';
    marker.setAttribute('aria-hidden', 'true');
    icon.append(marker);
  }
  if (icon) icon.querySelector('.muling-game-plus')?.setAttribute('title', amortissement);
  const freightEnabled=playerId===markerState?.playerId&&planet?.included&&markerState.options?.freight!==false;
  const greenEntries=freightEnabled&&component==='lfresearch'?planet.freightTechs||[]:freightEnabled&&component==='shipyard'&&planet.freightRecycler?[{id:'209',title:planet.freightRecycler}]:[];
  const greenIcons=new Map(greenEntries.map(entry=>[document.querySelector(`li.technology[data-technology="${CSS.escape(String(entry.id))}"] .icon`),entry.title]).filter(([icon])=>icon));
  for(const marker of document.querySelectorAll('.muling-game-freight'))if(!greenIcons.has(marker.parentElement))marker.remove();
  for(const [greenIcon,title] of greenIcons){
    greenIcon.classList.add('muling-marked-icon');
    let marker=greenIcon.querySelector('.muling-game-freight');
    if(!marker){marker=document.createElement('span');marker.className='muling-game-freight';marker.textContent='+';greenIcon.append(marker)}
    marker.title=title;
  }
  const blueDetails=playerId===markerState?.playerId&&planet?.included&&component==='lfbuildings' ? planet.unlockDetails||[]:[];
  const blueIds=blueDetails.length?blueDetails.map(x=>x.id):(playerId===markerState?.playerId&&planet?.included&&component==='lfbuildings'?planet.unlockIds||[]:[]);
  const blueIcons=new Map(blueIds.map(id=>[document.querySelector(`li.technology[data-technology="${CSS.escape(String(id))}"] .icon`),String(id)]).filter(([icon])=>icon));
  for(const marker of document.querySelectorAll('.muling-game-unlock'))if(!blueIcons.has(marker.parentElement))marker.remove();
  for(const [blueIcon,buildingId] of blueIcons){
    blueIcon.classList.add('muling-marked-icon');
    let marker=blueIcon.querySelector('.muling-game-unlock');
    if(!marker){marker=document.createElement('span');marker.className='muling-game-unlock';marker.textContent='+';blueIcon.append(marker)}
    const detail=blueDetails.find(x=>String(x.id)===buildingId);
    marker.title=detail?`${detail.name} ${detail.level}/${detail.required}${detail.queued>detail.level?` · niveau ${detail.queued} dans la file`:''} · objectif FDV`:'Bâtiment à monter pour l’objectif FDV';
  }
}
let lastLiveSignature = '';
function pendingLifeformResearch(levels) {
  const queue=document.querySelector('#productionboxlfresearchcomponent .construction');
  if(!queue||queue.querySelector('.idle'))return null;
  let id=queue.querySelector('[data-technology]')?.getAttribute('data-technology');
  if(!id){const match=queue.innerHTML.match(/lifeformTech(\d{5})/);id=match?.[1]}
  if(!id){const label=queue.querySelector('[data-tooltip-title], [aria-label]')?.getAttribute('data-tooltip-title')||queue.textContent;for(const tile of document.querySelectorAll('li.technology[data-technology]')){const title=tile.getAttribute('data-tooltip-title')||'';if(title.length>4&&label.includes(title)){id=tile.getAttribute('data-technology');break}}}
  if(!id){const running=[...document.querySelectorAll('li.technology[data-technology]')].filter(tile=>tile.querySelector('.countdown, .timer, .buildingCountdown'));if(running.length===1)id=running[0].getAttribute('data-technology')}
  if(!id||!Object.hasOwn(levels,id))return null;
  const levelText=queue.textContent.match(/(?:niveau|level)\s*(\d+)/i);
  return {id,nextLevel:Math.max(Number(levels[id])+1,Number(levelText?.[1]||0))};
}
function pendingLifeformBuildings(levels) {
  const box=document.querySelector('#productionboxlfbuildingcomponent');
  if(!box)return null;
  const planned={};
  const tiles=[...document.querySelectorAll('li.technology[data-technology]')];
  for(const node of box.querySelectorAll('[data-technology], [class*="lifeformTech"], img, [title], [aria-label]')){
    const context=[node.getAttribute('data-technology'),node.className?.baseVal||node.className,node.getAttribute('src'),node.getAttribute('title'),node.getAttribute('aria-label')].join(' ');
    let id=node.getAttribute('data-technology')||context.match(/lifeformTech(\d{5})/)?.[1];
    if(!id){const label=[node.getAttribute('title'),node.getAttribute('aria-label'),node.parentElement?.getAttribute('title')].filter(Boolean).join(' ');id=tiles.find(tile=>label.includes(tile.getAttribute('data-tooltip-title')||'\0'))?.getAttribute('data-technology')}
    if(!id||!Object.hasOwn(levels,id))continue;
    const text=[node.getAttribute('data-level'),node.getAttribute('title'),node.getAttribute('aria-label'),node.parentElement?.getAttribute('title'),node.parentElement?.textContent].filter(Boolean).join(' ');
    const explicit=text.match(/(?:niveau|level)\s*(\d+)/i)?.[1]||node.parentElement?.textContent?.trim().match(/^\d+$/)?.[0];
    planned[id]=Math.max(planned[id]||0,Number(levels[id])+1,Number(explicit||0));
  }
  if(!Object.keys(planned).length&&!box.querySelector('.construction .idle')){
    const title=box.querySelector('.construction')?.textContent||'';
    const tile=tiles.find(t=>title.includes(t.getAttribute('data-tooltip-title')||'\0'));
    if(tile){const id=tile.getAttribute('data-technology');planned[id]=Math.max(Number(levels[id])+1,Number(title.match(/(?:niveau|level)\s*(\d+)/i)?.[1]||0))}
  }
  return planned;
}
function captureLevels() {
  const component = new URLSearchParams(location.search).get('component');
  const field = {supplies:'buildings',lfresearch:'speciesResearches',lfbuildings:'speciesBuildings',research:'researches'}[component];
  const playerId = document.querySelector('meta[name="ogame-player-id"]')?.content;
  const planetId = currentPlanetId();
  if (!field || !playerId || !planetId) return;
  const levels = {};
  for (const item of document.querySelectorAll('li.technology[data-technology]')) {
    const id = item.getAttribute('data-technology');
    const value = item.querySelector('.level[data-value]')?.getAttribute('data-value');
    if (/^\d+$/.test(id || '') && /^\d+$/.test(value || '')) levels[id] = Number(value);
  }
  if (!Object.keys(levels).length) return;
  const pendingResearch=field==='speciesResearches'?pendingLifeformResearch(levels):undefined;
  const pendingBuildings=field==='speciesBuildings'?pendingLifeformBuildings(levels):undefined;
  const signature = JSON.stringify([playerId,planetId,field,levels,pendingResearch,pendingBuildings]);
  if (signature === lastLiveSignature) return;
  lastLiveSignature = signature;
  chrome.storage.local.get('mulingLiveLevels', ({mulingLiveLevels = {}}) => {
    const key = `${playerId}:${planetId}`;
    const old = mulingLiveLevels[key] || {};
    chrome.storage.local.set({mulingLiveLevels:{...mulingLiveLevels,[key]:{...old,[field]:levels,...(field==='speciesResearches'?{pendingResearch,selectedSpeciesTechnologyIds:Object.keys(levels)}:{}),...(pendingBuildings?{pendingBuildings}:{}),capturedAt:Date.now()}}});
  });
}
let captureTimer;
function scheduleCapture() { clearTimeout(captureTimer); captureTimer = setTimeout(captureLevels, 350); }
chrome.storage.local.get('mulingState', result => {
  markerState = result.mulingState || null;
  updateMarkers();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.mulingState) {
    markerState = changes.mulingState.newValue || null;
    updateMarkers();
  }
});
updateMarkers();
scheduleCapture();
new MutationObserver(() => { addMulingMenu(); updateMarkers(); scheduleCapture(); }).observe(document.documentElement, {childList:true, subtree:true, attributes:true, attributeFilter:['data-value']});
setInterval(captureLevels, 30000);
