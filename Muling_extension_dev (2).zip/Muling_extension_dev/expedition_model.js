/* Le Mulet V3.1, expe!B4:B12 / E9:E12 / B30:B33 / E30:E33.
 * Profile: optimal large-cargo expedition (50% metal cap), pathfinder sent.
 * Amounts below scale with expe!B46, chosen by first player's points.
 * The ship composition is exê fleet!B20:B22 for the workbook's pathfinder profile.
 * Daily expedition count replaces dont look that mess!B16; no schedule multiplier.
 */
const MulingExpeditionModel = Object.freeze({
 estimate({perDay,economy,topBase=50000,commander=false,discoverer=true,resourceBonus=0,shipBonus=0,classBonus=0,booster=0}) {
  if (![perDay,economy,topBase].every(v=>Number.isFinite(v)&&v>0) || ![400,5000,12000,18000,24000,30000,36000,42000,50000].includes(topBase)) return null;
  const large=.077*(commander?1.1:1),huge=.009*(commander?1.1:1),normal=1-large-huge;
  const normalMean=15*topBase,largeMean=38*topBase,hugeMean=75.5*topBase;
  const multiplier=2*(discoverer?1.5*economy:1),enhancement=discoverer?1+classBonus/100:1;
  const common=normal*normalMean+large*largeMean;
  const resFactor=multiplier*(1+booster/100)*(1+resourceBonus/100)*enhancement;
  const metal=.34*.5*(common+huge*50*topBase)*resFactor;
  const crystal=.34/3*.5*(common+huge*hugeMean)*resFactor;
  const deut=.34/6/3*(common+huge*hugeMean)*resFactor;
  const shipFactor=.17*.5*(.89*normalMean+.1*largeMean+.01*hugeMean)*multiplier*(1+shipBonus/100)*enhancement;
  const ships=shipFactor*(.4859737806+1.5*.5140262194+3*.04625603865);
  const resources=metal+1.5*crystal+3*deut;
  return {source:'theory',perDay,economy,topBase,metalPerExpedition:metal,crystalPerExpedition:crystal,deutPerExpedition:deut,msuPerExpedition:resources,msuPerDay:resources*perDay,shipsMsuPerDay:ships*perDay,resourceBonus,shipBonus,classBonus};
 }
});
