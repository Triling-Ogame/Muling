/* Structured espionage reports already present in OGame's message DOM. */
const MulingSpyCore=Object.freeze({
 sections:{fleet:'hiddenships',defense:'hiddendef',buildings:'hiddenbuildings',lfbuildings:'hiddenbuildings',research:'hiddenresearch',lfresearch:'hiddenresearch',repairorder:'hiddenrepairorder'},
 fromAttributes(attrs,messageId,clock,bodyName=''){
  const get=name=>attrs[`data-raw-${name}`],number=name=>{const value=get(name);return value!=null&&/^\d+$/.test(value)?Number(value):null},sections={};
  for(const [name,hidden] of Object.entries(this.sections)){
   const raw=get(name),flag=get(hidden);let values=null;
   if(raw!=null&&(flag===''||flag==='0')){const parsed=JSON.parse(raw);if(!parsed||typeof parsed!=='object')throw Error('Section de RE invalide');values=Object.fromEntries(Object.entries(parsed).map(([id,count])=>[id,Number(count)]));}
   sections[name]=values;
  }
  return this.validate({messageId:String(messageId),hash:get('hashcode')||'',player:get('playername'),playerId:get('targetplayerid'),coords:get('coordinates'),bodyType:number('targetplanettype'),bodyName,clock,resources:{metal:number('metal'),crystal:number('crystal'),deut:number('deuterium'),food:number('food'),population:number('population')},sections,activity:get('activity')||null,loot:number('loot'),counterEspionage:number('counterespionagechance'),fleetValue:number('fleetvalue'),defenseValue:number('defensevalue'),sources:[]});
 },
 validate(report){
  if(!report||typeof report!=='object')throw Error('RE invalide');
  const text=(value,max)=>String(value||'').trim().slice(0,max),player=text(report.player,80),playerId=text(report.playerId,30),coords=text(report.coords,40),clock=MulingSurveillanceCore.clock(report.clock);
  if(!player||!/^\d+$/.test(playerId)||!/^([1-9]\d*):([1-9]\d*):([1-9]|1[0-5])$/.test(coords)||![1,3].includes(report.bodyType)||!clock)throw Error('Identité, position ou date du RE non reconnue');
  const safe=value=>value===null?null:Number.isSafeInteger(value)&&value>=0?value:(()=>{throw Error('Valeur du RE invalide')})();
  const sections={};for(const key of Object.keys(this.sections)){const input=report.sections?.[key];if(input===null||input===undefined){sections[key]=null;continue}if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length>300)throw Error('Section du RE invalide');sections[key]=Object.fromEntries(Object.entries(input).map(([id,value])=>{if(!/^\d+$/.test(id))throw Error('Identifiant de technologie invalide');return [id,safe(value)]}));}
  const resources={};for(const key of ['metal','crystal','deut','food','population'])resources[key]=safe(report.resources?.[key]??null);
  const hash=text(report.hash,120),messageId=text(report.messageId,40),id=hash||`${playerId}:${coords}:${report.bodyType}:${clock.stamp}:${messageId}`;
  const sources=Array.isArray(report.sources)?report.sources.filter(s=>s&&typeof s.id==='string'&&typeof s.label==='string').slice(0,20).map(s=>({id:s.id.slice(0,160),label:s.label.slice(0,80)})):[];
  return {id,messageId,hash,player,playerId,playerKey:MulingSurveillanceCore.nameKey(player),coords,bodyType:report.bodyType,bodyName:text(report.bodyName,100),clock:String(report.clock),day:clock.day,time:clock.time,stamp:clock.stamp,resources,sections,activity:text(report.activity,80)||null,loot:safe(report.loot??null),counterEspionage:safe(report.counterEspionage??null),fleetValue:safe(report.fleetValue??null),defenseValue:safe(report.defenseValue??null),sources};
 },
 save(scope,input){
  const report=this.validate(input);scope.targets=scope.targets||[];scope.spyReports=scope.spyReports||[];
  let target=scope.targets.find(t=>t.playerId===report.playerId)||scope.targets.find(t=>t.key===report.playerKey);
  if(target?.playerId&&target.playerId!==report.playerId)throw Error('Ce pseudo est déjà associé à un autre joueur');
  if(!target){if(scope.targets.length>=500)throw Error('500 cibles maximum');target={name:report.player,key:report.playerKey,playerId:report.playerId};scope.targets.push(target)}else target.playerId=report.playerId;
  report.playerKey=target.key;
  const existing=scope.spyReports.find(r=>r.id===report.id);
  if(existing){existing.sources=[...new Map([...(existing.sources||[]),...report.sources].map(s=>[s.id,s])).values()].slice(0,20);return {added:false,playerKey:target.key,id:existing.id}}
  if(scope.spyReports.length>=1000)throw Error('1000 RE sauvegardés maximum. Exporte tes rapports avant de faire de la place.');
  scope.spyReports.push(report);scope.spyReports.sort((a,b)=>b.stamp-a.stamp);return {added:true,playerKey:target.key,id:report.id};
 }
});
