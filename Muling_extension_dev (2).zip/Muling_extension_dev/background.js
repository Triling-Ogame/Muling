chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
chrome.runtime.onMessage.addListener(message => { if (message?.type === 'openMuling') chrome.runtime.openOptionsPage(); });

if(typeof importScripts==='function')importScripts('surveillance_core.js','spy_core.js','surveillance_background.js');
